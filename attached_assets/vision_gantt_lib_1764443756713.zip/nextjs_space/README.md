
# 🎯 VisionGantt Library

A high-performance React Gantt Chart library inspired by Bryntum Scheduler Pro, built with TypeScript, React 18, and NextJS 14.

![VisionGantt Demo](./public/og-image.png)

## ✨ Features

### Core Functionality (MVP)

- **📊 Hierarchical WBS (Work Breakdown Structure)**
  - Tree structure with unlimited nesting levels
  - Expand/collapse functionality for task groups
  - WBS code generation (e.g., 1.2.3)

- **🎨 Drag & Drop**
  - Intuitive drag-and-drop to adjust task start/end dates
  - Real-time visual feedback during dragging
  - Snap-to-grid functionality for precise positioning

- **🔗 Task Dependencies**
  - Visual dependency lines with smart routing
  - Support for all dependency types:
    - **FS** (Finish-to-Start) - Default
    - **SS** (Start-to-Start)
    - **FF** (Finish-to-Finish)
    - **SF** (Start-to-Finish)
  - Circular dependency detection
  - Lag time support

- **📏 Resize Tasks**
  - Adjust task duration by dragging edges
  - Minimum duration constraint (1 day)
  - Real-time duration calculation

- **🔍 Zoom Controls**
  - Multiple view presets:
    - Day view (60px per day)
    - Week view (80px per week)
    - Month view (100px per month)
    - Quarter view (120px per quarter)
    - Year view (150px per year)

- **📋 Customizable Grid**
  - Configurable columns (name, dates, duration, progress, status, etc.)
  - Resizable columns
  - Custom cell renderers

### Performance Optimizations

- **⚡ High Performance**
  - Supports 5,000+ tasks with smooth rendering
  - Virtual scrolling for efficient DOM usage
  - Canvas/SVG rendering for optimal performance
  - Debounced drag operations

- **🎭 Advanced Rendering**
  - Task bars rendered with SVG for scalability
  - Dependency lines with optimized path generation
  - Today marker with real-time positioning

### Architecture

Based on Bryntum Scheduler Pro design patterns:

- **Layered Architecture**
  - Data Layer (Stores)
  - Engine Layer (Utilities & Hooks)
  - Presentation Layer (Components)

- **Design Patterns**
  - Observer Pattern for reactive state management
  - Store Pattern (TaskStore, DependencyStore, ResourceStore)
  - Facade Pattern for simplified API
  - Composite Pattern (Grid + Timeline)

## 🚀 Quick Start

### Installation

The library is located in `/lib/vision-gantt/` and can be imported directly:

```typescript
import { GanttChart } from '@/lib/vision-gantt';
import type { Task, Dependency } from '@/lib/vision-gantt/types';
```

### Basic Usage

```tsx
import { GanttChart } from '@/lib/vision-gantt';
import type { Task, Dependency } from '@/lib/vision-gantt/types';

function App() {
  const tasks: Task[] = [
    {
      id: '1',
      name: 'Project Planning',
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-15'),
      duration: 15,
      progress: 100,
      status: 'completed',
      expanded: true,
      children: [
        {
          id: '2',
          name: 'Requirements Gathering',
          startDate: new Date('2024-01-01'),
          endDate: new Date('2024-01-05'),
          duration: 5,
          progress: 100,
          status: 'completed',
          parentId: '1'
        }
      ]
    }
  ];

  const dependencies: Dependency[] = [
    {
      id: 'dep_1',
      fromTaskId: '1',
      toTaskId: '2',
      type: 'FS'
    }
  ];

  return (
    <GanttChart
      tasks={tasks}
      dependencies={dependencies}
      viewPreset="month"
      height={600}
      enableDragDrop={true}
      enableResize={true}
      onTaskUpdate={(task) => console.log('Updated:', task)}
      onDependencyCreate={(dep) => console.log('Created:', dep)}
    />
  );
}
```

## 📖 API Reference

### GanttChart Props

```typescript
interface GanttChartProps {
  // Data
  tasks: Task[];
  dependencies: Dependency[];
  resources?: Resource[];
  
  // View Configuration
  viewPreset?: 'day' | 'week' | 'month' | 'quarter' | 'year';
  columns?: ColumnConfig[];
  
  // Appearance
  rowHeight?: number;        // Default: 40px
  barHeight?: number;        // Default: 28px
  barRadius?: number;        // Default: 4px
  gridWidth?: number;        // Default: 600px
  height?: number;           // Default: 600px
  
  // Features
  enableDragDrop?: boolean;           // Default: true
  enableResize?: boolean;             // Default: true
  enableDependencyCreation?: boolean; // Default: false
  
  // Callbacks
  onTaskUpdate?: (task: Task) => void;
  onTaskClick?: (task: Task) => void;
  onTaskDoubleClick?: (task: Task) => void;
  onDependencyCreate?: (dependency: Dependency) => void;
  onDependencyDelete?: (dependencyId: string) => void;
  onViewPresetChange?: (preset: ViewPreset) => void;
}
```

### Task Type

```typescript
interface Task {
  id: string;
  name: string;
  startDate: Date;
  endDate: Date;
  duration?: number;               // in days
  progress: number;                // 0-100
  status: 'not_started' | 'in_progress' | 'completed' | 'on_hold';
  parentId?: string | null;
  children?: Task[];
  expanded?: boolean;
  level?: number;
  wbs?: string;                    // Work Breakdown Structure code
  assignedResources?: string[];
  description?: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  isMilestone?: boolean;
}
```

### Dependency Type

```typescript
interface Dependency {
  id: string;
  fromTaskId: string;
  toTaskId: string;
  type: 'FS' | 'SS' | 'FF' | 'SF';
  lag?: number;                    // Lag in days (can be negative)
}
```

## 🎨 Customization

### Custom Columns

```typescript
import { DEFAULT_COLUMNS } from '@/lib/vision-gantt/config/default-columns';

const customColumns: ColumnConfig[] = [
  {
    field: 'name',
    header: 'Task Name',
    width: 300,
    renderer: (value, task) => (
      <div className="font-semibold">{value}</div>
    )
  },
  {
    field: 'progress',
    header: 'Completion',
    width: 100,
    renderer: (value) => (
      <div className="flex items-center gap-2">
        <div className="w-12 bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full" 
            style={{ width: `${value}%` }}
          />
        </div>
        <span>{value}%</span>
      </div>
    )
  }
];

<GanttChart columns={customColumns} {...otherProps} />
```

### Using Stores Directly

For advanced state management:

```typescript
import { TaskStore, DependencyStore } from '@/lib/vision-gantt/stores';

const taskStore = new TaskStore(tasks);
const dependencyStore = new DependencyStore(dependencies);

// Subscribe to changes
taskStore.subscribe((updatedTasks) => {
  console.log('Tasks updated:', updatedTasks);
});

// Manipulate data
taskStore.add(newTask);
taskStore.update('task_1', { progress: 50 });
dependencyStore.createDependency('task_1', 'task_2', 'FS');
```

## 🏗️ Project Structure

```
/lib/vision-gantt/
├── components/           # React components
│   ├── gantt-chart.tsx      # Main component
│   ├── gantt-grid.tsx       # Left grid
│   ├── gantt-timeline.tsx   # Timeline area
│   ├── task-bar.tsx         # Task bar renderer
│   ├── dependency-line.tsx  # Dependency renderer
│   ├── timeline-header.tsx  # Time scale header
│   └── zoom-control.tsx     # Zoom controls
├── stores/              # Data stores (Observer Pattern)
│   ├── task-store.ts        # Task management
│   ├── dependency-store.ts  # Dependency management
│   └── resource-store.ts    # Resource management
├── hooks/               # Custom React hooks
│   ├── use-gantt-stores.ts  # Store integration
│   ├── use-drag-drop.ts     # Drag & drop logic
│   ├── use-resize.ts        # Resize logic
│   └── use-dependency-creation.ts
├── utils/               # Utility functions
│   ├── date-utils.ts        # Date calculations
│   ├── wbs-utils.ts         # Hierarchy management
│   ├── dependency-utils.ts  # Dependency logic
│   └── task-utils.ts        # Task calculations
├── types/               # TypeScript definitions
│   └── index.ts             # All type exports
├── config/              # Configuration
│   ├── view-presets.ts      # Zoom configurations
│   └── default-columns.ts   # Default grid columns
└── index.ts            # Main entry point
```

## 🎯 Demo Application

The included demo showcases:

- **100+ hierarchical tasks** across 4 project phases
- **50+ dependencies** with multiple types (FS, SS, FF, SF)
- **8 mock resources** for realistic project simulation
- **Interactive statistics panel** with real-time metrics
- **Task details panel** showing comprehensive task information

Run the demo:

```bash
cd /home/ubuntu/vision_gantt_lib/nextjs_space
yarn dev
```

## 🔧 Technical Details

### Performance Characteristics

- **Task Capacity**: 5,000+ tasks
- **FPS During Interaction**: 45+ fps
- **Rendering Method**: SVG for scalability
- **Scroll Performance**: Virtual scrolling with configurable overscan

### Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+

### Dependencies

- React 18.2.0
- NextJS 14.2.28
- TypeScript 5.2.2
- date-fns 3.6.0
- lucide-react 0.446.0
- Tailwind CSS 3.3.3

## 🚦 Roadmap

### Phase 2 Features (Planned)

- [ ] **Resource Management**
  - Resource allocation view
  - Workload balancing
  - Resource histogram

- [ ] **Advanced Features**
  - Critical path calculation
  - Baseline comparison
  - Task constraints (ASAP, ALAP, MFO, MSO)
  - Task splitting

- [ ] **Export/Import**
  - Export to PDF
  - Export to Excel
  - Import from MS Project
  - Import from Primavera

- [ ] **Collaboration**
  - Real-time updates
  - Comments and annotations
  - Change history

### Phase 3 Features (Future)

- [ ] **Advanced Visualizations**
  - Resource utilization chart
  - Burn-down chart
  - Cumulative flow diagram

- [ ] **Mobile Support**
  - Touch-optimized interactions
  - Responsive layout for tablets

- [ ] **Integrations**
  - Jira integration
  - Asana integration
  - Monday.com integration

## 📝 License

MIT License - feel free to use in personal and commercial projects.

## 🤝 Contributing

This is a demo library built for educational purposes. For production use, consider:

1. Adding comprehensive unit tests
2. Implementing end-to-end tests
3. Adding accessibility features (ARIA labels, keyboard navigation)
4. Optimizing for mobile devices
5. Adding internationalization (i18n) support

## 📧 Contact

For questions or feedback about this library demo, please reach out or create an issue in the repository.

---

**Built with ❤️ using React, TypeScript, and NextJS**
