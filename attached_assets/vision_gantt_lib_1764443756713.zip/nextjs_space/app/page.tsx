
/**
 * VisionGantt Complete Demo Application
 * Demonstrates ALL library capabilities:
 * - WBS with indentation and predecessor/successor columns
 * - Resizable columns with localStorage persistence
 * - Auto WBS numbering
 * - Task hierarchy with expand/collapse
 * - Interactive Gantt chart with drag & drop
 * - Dependency creation with visual feedback
 * - Resource management and conflict detection
 * - Scenario comparison
 * - Working calendars and holidays
 * - Constraint validation
 * - Export to JSON, CSV, and MS Project XML
 * - Full toolbar with all features
 */

import { FullFeaturesDemo } from '@/components/full-features-demo';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-[1800px] mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            VisionGantt Library - Complete Feature Demonstration
          </h1>
          <p className="text-gray-600">
            Professional Gantt chart library with WBS, dependencies, resources, calendars, and more
          </p>
        </div>

        {/* Demo Component */}
        <FullFeaturesDemo />
      </div>
    </div>
  );
}
