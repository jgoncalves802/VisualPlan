
# VisionGantt Advanced Features Documentation

Este documento descreve as funcionalidades avançadas implementadas na biblioteca VisionGantt.

## 📋 Índice

- [Melhorias da Interface](#melhorias-da-interface)
- [RF-L06 a RF-L10: Alocação de Recursos Avançada](#rf-l06-a-rf-l10-alocação-de-recursos-avançada)
- [RF-L14 a RF-L16: Cenários de Simulação](#rf-l14-a-rf-l16-cenários-de-simulação)
- [RF-L17 a RF-L19: Calendários e Restrições Complexas](#rf-l17-a-rf-l19-calendários-e-restrições-complexas)
- [Exemplos de Uso](#exemplos-de-uso)

---

## Melhorias da Interface

### 1. ✨ Cabeçalho Timeline com Texto Fixo

**Problema Resolvido:** O texto das camadas superiores do timeline desaparecia durante o scroll horizontal.

**Solução:** Implementado posicionamento sticky no texto das camadas superiores com alinhamento à esquerda.

**Comportamento:**
- Camadas superiores (meses, anos) sempre visíveis à esquerda durante scroll
- Camada inferior (dias, horas, semanas) mantém comportamento centralizado
- Texto bold nas camadas superiores para melhor legibilidade

### 2. 🔧 Colunas Redimensionáveis

**Funcionalidade:** Permite ao usuário ajustar a largura das colunas da grid.

**Características:**
- Handle de resize visível ao passar o mouse sobre o cabeçalho da coluna
- Ícone de grip vertical para indicar área de resize
- Feedback visual durante o redimensionamento (linha azul)
- Largura mínima de 50px para evitar colunas muito estreitas
- Sincronização automática entre header e células

**Uso:**
```tsx
<GanttGrid
  tasks={tasks}
  columns={columns}
  rowHeight={40}
  onColumnResize={(columnIndex, newWidth) => {
    console.log(`Column ${columnIndex} resized to ${newWidth}px`);
  }}
/>
```

---

## RF-L06 a RF-L10: Alocação de Recursos Avançada

### Tipos Disponíveis

#### ResourceAllocation
```typescript
interface ResourceAllocation {
  id: string;
  taskId: string;
  resourceId: string;
  units: number; // Percentual (0-100) ou horas por dia
  startDate: Date;
  endDate: Date;
  type: 'percentage' | 'hours';
  cost?: number;
}
```

#### ResourceConflict
```typescript
interface ResourceConflict {
  id: string;
  resourceId: string;
  date: Date;
  allocatedUnits: number;
  availableUnits: number;
  overallocation: number;
  affectedTasks: string[];
  severity: 'low' | 'medium' | 'high' | 'critical';
}
```

### Funcionalidades

#### 1. Detecção de Sobrealocação

```typescript
import { detectResourceConflicts } from '@/lib/vision-gantt/utils/resource-utils';

const conflicts = detectResourceConflicts(
  allocations,
  availabilities,
  { startDate: new Date('2025-01-01'), endDate: new Date('2025-12-31') },
  resources
);

// Resultado: array de conflitos com severidade e tarefas afetadas
conflicts.forEach(conflict => {
  console.log(`Resource ${conflict.resourceId} overallocated by ${conflict.overallocation} units`);
  console.log(`Affected tasks: ${conflict.affectedTasks.join(', ')}`);
});
```

#### 2. Nivelamento de Recursos

```typescript
import { levelResources } from '@/lib/vision-gantt/utils/resource-utils';

const options: ResourceLevelingOptions = {
  mode: 'automatic',
  strategy: 'delay_tasks', // ou 'split_tasks', 'reduce_allocation'
  priority: 'critical_path',
  allowTaskSplitting: false,
  respectTaskConstraints: true,
  maxIterations: 100
};

const result = levelResources(tasks, allocations, availabilities, resources, options);

// Resultado: tarefas ajustadas, alocações atualizadas, conflitos restantes
console.log(`Adjusted ${result.tasks.length} tasks`);
console.log(`Remaining conflicts: ${result.conflicts.length}`);
```

#### 3. Cálculo de Utilização de Recursos

```typescript
import { calculateResourceUtilization } from '@/lib/vision-gantt/utils/resource-utils';

const utilization = calculateResourceUtilization(
  'resource-1',
  allocations,
  availabilities,
  { startDate: new Date('2025-01-01'), endDate: new Date('2025-12-31') },
  8 // 8 horas por dia
);

console.log(`Resource utilization: ${utilization.toFixed(1)}%`);
```

#### 4. Buscar Recursos Disponíveis

```typescript
import { findAvailableResources } from '@/lib/vision-gantt/utils/resource-utils';

const availableResources = findAvailableResources(
  task,
  resources,
  allocations,
  availabilities,
  8 // horas requeridas por dia
);

console.log(`${availableResources.length} resources available for this task`);
```

---

## RF-L14 a RF-L16: Cenários de Simulação

### Tipos Disponíveis

#### Scenario
```typescript
interface Scenario {
  id: string;
  name: string;
  description?: string;
  baselineDate: Date;
  createdDate: Date;
  status: 'draft' | 'active' | 'archived';
  changes: ScenarioChange[];
  metrics: ScenarioMetrics;
}
```

#### ScenarioMetrics
```typescript
interface ScenarioMetrics {
  totalDuration: number; // Dias
  projectEndDate: Date;
  totalCost: number;
  resourceUtilization: number; // Percentual
  criticalPathLength: number; // Dias
  riskScore: number; // 0-100
  completionProbability: number; // Percentual
}
```

### Funcionalidades

#### 1. Criar Cenário Base

```typescript
import { createScenario } from '@/lib/vision-gantt/utils/scenario-utils';

const scenario = createScenario(
  'Scenario Otimista',
  'Considera que todos os recursos estarão disponíveis',
  tasks,
  dependencies
);

console.log(`Scenario created with ${scenario.metrics.completionProbability}% probability`);
```

#### 2. Aplicar Mudanças e Criar Novo Cenário

```typescript
import { applyScenarioChanges, calculateChangeImpact } from '@/lib/vision-gantt/utils/scenario-utils';

// Calcular impacto de uma mudança antes de aplicar
const change = calculateChangeImpact(
  tasks,
  dependencies,
  {
    type: 'task_duration',
    entityId: 'task-1',
    field: 'duration',
    originalValue: 30,
    newValue: 20 // Reduzir de 30 para 20 dias
  }
);

console.log(`Impact: ${change.impact?.dateShift} days shift, ${change.impact?.affectedTasks} affected tasks`);

// Aplicar mudanças
const result = applyScenarioChanges(baseScenario, tasks, [change]);

console.log(`New scenario end date: ${result.scenario.metrics.projectEndDate}`);
console.log(`Cost delta: $${result.scenario.metrics.totalCost - baseScenario.metrics.totalCost}`);
```

#### 3. Comparar Cenários

```typescript
import { compareScenarios } from '@/lib/vision-gantt/utils/scenario-utils';

const comparison = compareScenarios([
  scenarioOptimistic,
  scenarioRealistic,
  scenarioPessimistic
]);

// Ver diferenças
comparison.differences.forEach(diff => {
  const scenario = comparison.scenarios.find(s => s.id === diff.scenarioId);
  console.log(`${scenario?.name}:`);
  console.log(`  Duration delta: ${diff.durationDelta} days`);
  console.log(`  Cost delta: $${diff.costDelta}`);
  console.log(`  Critical changes: ${diff.criticalChanges.join(', ')}`);
});

// Ver recomendações
comparison.recommendations?.forEach(rec => console.log(`✓ ${rec}`));
```

---

## RF-L17 a RF-L19: Calendários e Restrições Complexas

### Tipos Disponíveis

#### WorkingCalendar
```typescript
interface WorkingCalendar {
  id: string;
  name: string;
  timeZone?: string;
  workingDays: WorkingDay[];
  holidays: Holiday[];
  exceptions: CalendarException[];
  defaultStartTime: string; // "09:00"
  defaultEndTime: string; // "17:00"
}
```

#### TaskConstraint
```typescript
type TaskConstraintType =
  | 'ASAP' // As Soon As Possible (default)
  | 'ALAP' // As Late As Possible
  | 'SNET' // Start No Earlier Than
  | 'SNLT' // Start No Later Than
  | 'FNET' // Finish No Earlier Than
  | 'FNLT' // Finish No Later Than
  | 'MSO'  // Must Start On
  | 'MFO'; // Must Finish On

interface TaskConstraint {
  taskId: string;
  type: TaskConstraintType;
  date?: Date;
  priority: number;
  violationTolerance?: number; // Dias permitidos para violar
}
```

### Funcionalidades

#### 1. Criar Calendário de Trabalho

```typescript
import { getDefaultCalendar } from '@/lib/vision-gantt/utils/calendar-utils';

// Calendário padrão (Segunda a Sexta, 9h-17h)
const defaultCalendar = getDefaultCalendar();

// Calendário customizado
const customCalendar: WorkingCalendar = {
  id: 'custom-1',
  name: 'Calendário Brasileiro',
  description: 'Segunda a Sexta, 8h-18h com almoço',
  workingDays: [
    { dayOfWeek: 0, isWorking: false }, // Domingo
    { dayOfWeek: 1, isWorking: true, workingHours: [
      { startTime: '08:00', endTime: '12:00' },
      { startTime: '13:00', endTime: '18:00' }
    ]},
    { dayOfWeek: 2, isWorking: true, workingHours: [
      { startTime: '08:00', endTime: '12:00' },
      { startTime: '13:00', endTime: '18:00' }
    ]},
    // ... outros dias
  ],
  holidays: [
    { id: 'h1', name: 'Ano Novo', date: new Date('2025-01-01'), recurring: true, type: 'public' },
    { id: 'h2', name: 'Carnaval', date: new Date('2025-03-04'), recurring: false, type: 'public' }
  ],
  exceptions: [],
  defaultStartTime: '08:00',
  defaultEndTime: '18:00'
};
```

#### 2. Verificar Dias Úteis

```typescript
import { isWorkingDay, calculateWorkingTime } from '@/lib/vision-gantt/utils/calendar-utils';

// Verificar se é dia útil
const isWorking = isWorkingDay(new Date('2025-11-19'), calendar);
console.log(`Is working day: ${isWorking}`);

// Calcular horas úteis em um período
const workingTime = calculateWorkingTime(
  new Date('2025-11-01'),
  new Date('2025-11-30'),
  calendar
);

console.log(`Working days: ${workingTime.totalDays}`);
console.log(`Working hours: ${workingTime.totalHours}`);
console.log(`Non-working dates: ${workingTime.nonWorkingDates.length}`);
```

#### 3. Adicionar Dias Úteis

```typescript
import { addWorkingDays } from '@/lib/vision-gantt/utils/calendar-utils';

const startDate = new Date('2025-11-19'); // Quarta-feira
const newDate = addWorkingDays(startDate, 5, calendar); // +5 dias úteis

console.log(`New date: ${newDate}`); // Próxima Quarta-feira (pula fim de semana)
```

#### 4. Validar Restrições de Tarefas

```typescript
import { validateConstraint, applyConstraint } from '@/lib/vision-gantt/utils/calendar-utils';

// Definir restrição
const constraint: TaskConstraint = {
  taskId: 'task-1',
  type: 'FNLT', // Finish No Later Than
  date: new Date('2025-12-31'),
  priority: 5,
  violationTolerance: 2 // Permite 2 dias de tolerância
};

// Validar se a tarefa viola a restrição
const violation = validateConstraint(task, constraint, calendar);

if (violation) {
  console.log(`Constraint violated by ${violation.violation} days`);
  console.log(`Severity: ${violation.severity}`);
  console.log(`Suggested fix: ${violation.suggestedFix}`);

  // Aplicar restrição automaticamente (se possível)
  if (violation.canAutoResolve) {
    const adjustedTask = applyConstraint(task, constraint, calendar);
    console.log(`Task adjusted: new end date ${adjustedTask.endDate}`);
  }
}
```

---

## Exemplos de Uso

### Exemplo Completo: Gerenciamento de Projeto com Todas as Funcionalidades

```typescript
import { GanttChart } from '@/lib/vision-gantt';
import {
  detectResourceConflicts,
  levelResources,
  calculateResourceUtilization
} from '@/lib/vision-gantt/utils/resource-utils';
import {
  createScenario,
  compareScenarios,
  applyScenarioChanges
} from '@/lib/vision-gantt/utils/scenario-utils';
import {
  getDefaultCalendar,
  validateConstraint,
  calculateWorkingTime
} from '@/lib/vision-gantt/utils/calendar-utils';

function ProjectManagement() {
  // 1. Setup inicial
  const calendar = getDefaultCalendar();
  const tasks = /* suas tarefas */;
  const resources = /* seus recursos */;
  const allocations = /* suas alocações */;

  // 2. Detectar conflitos de recursos
  const conflicts = detectResourceConflicts(
    allocations,
    [],
    { startDate: tasks[0].startDate, endDate: tasks[tasks.length-1].endDate },
    resources
  );

  if (conflicts.length > 0) {
    console.log(`⚠️ ${conflicts.length} resource conflicts detected`);
    
    // 3. Nivelar recursos automaticamente
    const leveled = levelResources(
      tasks,
      allocations,
      [],
      resources,
      {
        mode: 'automatic',
        strategy: 'delay_tasks',
        priority: 'critical_path',
        allowTaskSplitting: false,
        respectTaskConstraints: true
      }
    );
    
    console.log(`✓ Leveling complete. Remaining conflicts: ${leveled.conflicts.length}`);
  }

  // 4. Criar cenários de simulação
  const baselineScenario = createScenario(
    'Baseline',
    'Current project plan',
    tasks,
    []
  );

  const optimisticScenario = applyScenarioChanges(
    baselineScenario,
    tasks,
    [
      {
        type: 'task_duration',
        entityId: 'task-1',
        field: 'duration',
        originalValue: 30,
        newValue: 20
      }
    ]
  ).scenario;

  // 5. Comparar cenários
  const comparison = compareScenarios([baselineScenario, optimisticScenario]);
  
  console.log('📊 Scenario Comparison:');
  comparison.recommendations?.forEach(rec => console.log(`  ${rec}`));

  // 6. Validar restrições
  tasks.forEach(task => {
    const constraint: TaskConstraint = {
      taskId: task.id,
      type: 'FNLT',
      date: new Date('2025-12-31'),
      priority: 5
    };
    
    const violation = validateConstraint(task, constraint, calendar);
    if (violation) {
      console.log(`⚠️ Task ${task.name} violates constraint by ${violation.violation} days`);
    }
  });

  // 7. Calcular utilização de recursos
  resources.forEach(resource => {
    const utilization = calculateResourceUtilization(
      resource.id,
      allocations,
      [],
      { startDate: tasks[0].startDate, endDate: tasks[tasks.length-1].endDate },
      resource.capacity
    );
    
    console.log(`Resource ${resource.name}: ${utilization.toFixed(1)}% utilization`);
  });

  // 8. Renderizar Gantt Chart
  return (
    <GanttChart
      tasks={tasks}
      resources={resources}
      dependencies={[]}
      viewPreset="week"
      height={800}
      enableDragDrop={true}
      enableResize={true}
      onColumnResize={(index, width) => {
        console.log(`Column ${index} resized to ${width}px`);
      }}
    />
  );
}
```

---

## 🎯 Próximos Passos

As funcionalidades avançadas estão implementadas como utilitários. Para integrá-las completamente na interface do Gantt Chart, você pode:

1. **Criar componentes UI para:**
   - Painel de conflitos de recursos
   - Comparador de cenários
   - Editor de calendários
   - Gerenciador de restrições

2. **Adicionar stores para:**
   - ResourceAllocationStore
   - ScenarioStore
   - CalendarStore

3. **Integrar com o GanttChart:**
   - Visualização de sobrealocação de recursos
   - Indicadores de violação de restrições
   - Comparação visual de cenários

---

## 📚 Referências

- Tipos: `/lib/vision-gantt/types/advanced-features.ts`
- Utilitários de Recursos: `/lib/vision-gantt/utils/resource-utils.ts`
- Utilitários de Calendário: `/lib/vision-gantt/utils/calendar-utils.ts`
- Utilitários de Cenários: `/lib/vision-gantt/utils/scenario-utils.ts`
- Hook de Resize: `/lib/vision-gantt/hooks/use-column-resize.ts`

