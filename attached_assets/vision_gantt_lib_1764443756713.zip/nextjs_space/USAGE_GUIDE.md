
# 📘 Guia de Uso - Componentes Avançados VisionGantt

## 📁 Estrutura de Arquivos Criados

```
lib/vision-gantt/
├── stores/                     # Gerenciamento de estado
│   ├── resource-store.ts      ✅ Store de recursos e alocações
│   ├── scenario-store.ts      ✅ Store de cenários
│   ├── calendar-store.ts      ✅ Store de calendários
│   ├── constraint-store.ts    ✅ Store de restrições
│   └── index.ts               ✅ Exportações
│
├── hooks/                      # React Hooks
│   ├── use-advanced-stores.ts ✅ Hook para usar stores avançados
│   └── use-gantt-stores.ts    ✅ Hook para stores básicos
│
├── components/                 # Componentes UI
│   └── resource-panel.tsx     ✅ Painel de recursos
│
└── types/
    └── advanced-features.ts    ✅ Tipos TypeScript
```

---

## 🎯 Como Acessar os Componentes

### 1️⃣ **Importando os Stores**

```typescript
// Importar stores individuais
import { 
  ResourceStore, 
  ScenarioStore, 
  CalendarStore, 
  ConstraintStore 
} from '@/lib/vision-gantt';

// OU importar do caminho completo
import { ResourceStore } from '@/lib/vision-gantt/stores/resource-store';
```

### 2️⃣ **Usando o Hook `useAdvancedStores`**

```typescript
import { useAdvancedStores } from '@/lib/vision-gantt/hooks/use-advanced-stores';
import type { Resource } from '@/lib/vision-gantt/types';
import type { ResourceAllocation } from '@/lib/vision-gantt/types/advanced-features';

function MyComponent() {
  // Dados iniciais
  const resources: Resource[] = [
    { id: 'r1', name: 'John Doe', role: 'Developer', capacity: 8 },
    { id: 'r2', name: 'Jane Smith', role: 'Designer', capacity: 8 }
  ];

  const allocations: ResourceAllocation[] = [
    {
      id: 'a1',
      resourceId: 'r1',
      taskId: 't1',
      units: 8,
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-05')
    }
  ];

  // Usar o hook
  const {
    resourceStore,
    scenarioStore,
    calendarStore,
    constraintStore,
    resources: currentResources,
    conflicts,
    scenarios,
    calendars,
    constraints,
    violations
  } = useAdvancedStores({
    resources,
    allocations,
    scenarios: [],
    calendars: [],
    constraints: []
  });

  // Agora você pode usar os stores e os dados!
  return <div>...</div>;
}
```

### 3️⃣ **Usando o ResourcePanel**

```typescript
'use client';

import React, { useState } from 'react';
import { ResourcePanel } from '@/lib/vision-gantt/components/resource-panel';
import { useAdvancedStores } from '@/lib/vision-gantt/hooks/use-advanced-stores';
import type { Task } from '@/lib/vision-gantt/types';

export function MyGanttApp() {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: 't1',
      name: 'Task 1',
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-10'),
      progress: 50,
      status: 'in_progress'
    }
  ]);

  const { resourceStore } = useAdvancedStores({
    resources: [
      { id: 'r1', name: 'Developer A', role: 'Dev', capacity: 8 }
    ],
    allocations: [
      {
        id: 'a1',
        resourceId: 'r1',
        taskId: 't1',
        units: 8,
        startDate: new Date('2024-01-01'),
        endDate: new Date('2024-01-10')
      }
    ]
  });

  return (
    <div className="h-screen">
      <ResourcePanel
        resourceStore={resourceStore}
        tasks={tasks}
        onTasksUpdate={(updatedTasks) => {
          setTasks(updatedTasks);
        }}
      />
    </div>
  );
}
```

---

## 🔧 Operações Básicas

### **ResourceStore - Gerenciar Recursos**

```typescript
const { resourceStore } = useAdvancedStores({ resources: [] });

// ➕ Adicionar recurso
resourceStore.addResource({
  id: 'r3',
  name: 'Alice Johnson',
  role: 'Project Manager',
  capacity: 8
});

// ✏️ Atualizar recurso
resourceStore.updateResource('r3', {
  capacity: 6,
  role: 'Senior PM'
});

// 🗑️ Remover recurso
resourceStore.removeResource('r3');

// 📊 Obter utilização
const utilization = resourceStore.getResourceUtilization('r1', {
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-31')
});
console.log(`Utilization: ${utilization}%`);

// ⚠️ Obter conflitos
const conflicts = resourceStore.getConflicts();
console.log(`Conflicts found: ${conflicts.length}`);

// ⚡ Nivelamento automático
const result = await resourceStore.levelResources(tasks, {
  mode: 'automatic',
  strategy: 'delay_tasks',
  priority: 'critical_path'
});
```

### **ScenarioStore - Gerenciar Cenários**

```typescript
const { scenarioStore } = useAdvancedStores({ scenarios: [] });

// ➕ Criar novo cenário
const scenario = scenarioStore.createNewScenario(
  'Optimistic Scenario',
  'Best case scenario with all resources available',
  tasks,
  dependencies
);

// 🎯 Definir cenário ativo
scenarioStore.setActiveScenario(scenario.id);

// 📊 Comparar cenários
const comparison = scenarioStore.compare([scenario1.id, scenario2.id]);
console.log('Comparison:', comparison);

// 🔄 Clonar cenário
const cloned = scenarioStore.cloneScenario(scenario.id, 'Copy of Optimistic');
```

### **CalendarStore - Gerenciar Calendários**

```typescript
const { calendarStore } = useAdvancedStores({ calendars: [] });

// 📅 Adicionar feriado
calendarStore.addHoliday('calendar-1', {
  id: 'h1',
  name: 'Christmas',
  date: new Date('2024-12-25'),
  isRecurring: true
});

// ⏰ Adicionar exceção
calendarStore.addException('calendar-1', {
  id: 'e1',
  startDate: new Date('2024-12-24'),
  endDate: new Date('2024-12-24'),
  isWorking: false,
  reason: 'Christmas Eve'
});

// 🔄 Clonar calendário
const newCalendar = calendarStore.cloneCalendar('calendar-1', 'US Calendar 2');
```

### **ConstraintStore - Gerenciar Restrições**

```typescript
const { constraintStore } = useAdvancedStores({ constraints: [] });

// ➕ Adicionar restrição
constraintStore.addConstraint({
  taskId: 't1',
  type: 'must_start_on',
  date: new Date('2024-01-15'),
  priority: 'high'
});

// ✅ Validar todas as restrições
constraintStore.validateAllConstraints(tasks, calendar);

// 🔧 Aplicar correções automáticas
const result = constraintStore.applyConstraints(tasks, calendar);
console.log(`Resolved: ${result.resolved}, Remaining: ${result.remaining}`);
```

---

## 🎨 Exemplo Completo de Integração

```typescript
'use client';

import React, { useState } from 'react';
import { ResourcePanel } from '@/lib/vision-gantt/components/resource-panel';
import { useAdvancedStores } from '@/lib/vision-gantt/hooks/use-advanced-stores';
import { GanttChart } from '@/lib/vision-gantt';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function AdvancedGanttDemo() {
  const [tasks, setTasks] = useState([...mockTasks]);

  const {
    resourceStore,
    scenarioStore,
    calendarStore,
    constraintStore,
    conflicts
  } = useAdvancedStores({
    resources: mockResources,
    allocations: mockAllocations,
    scenarios: [],
    calendars: [],
    constraints: []
  });

  return (
    <div className="h-screen flex flex-col">
      {/* Header com estatísticas */}
      <div className="bg-white border-b p-4">
        <h1 className="text-2xl font-bold">Advanced Gantt Chart</h1>
        <p className="text-sm text-gray-600">
          {conflicts.length} conflicts detected
        </p>
      </div>

      {/* Layout com Gantt + Painéis */}
      <div className="flex-1 flex">
        {/* Gantt Chart - 70% */}
        <div className="w-[70%] border-r">
          <GanttChart
            tasks={tasks}
            dependencies={mockDependencies}
            viewPreset="week"
            height={800}
            gridWidth={400}
            enableDragDrop={true}
            onTaskUpdate={(task) => {
              const index = tasks.findIndex(t => t.id === task.id);
              if (index !== -1) {
                const newTasks = [...tasks];
                newTasks[index] = task;
                setTasks(newTasks);
              }
            }}
          />
        </div>

        {/* Painéis Avançados - 30% */}
        <div className="w-[30%]">
          <Tabs defaultValue="resources" className="h-full">
            <TabsList className="w-full">
              <TabsTrigger value="resources">Resources</TabsTrigger>
              <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
              <TabsTrigger value="calendars">Calendars</TabsTrigger>
              <TabsTrigger value="constraints">Constraints</TabsTrigger>
            </TabsList>

            <TabsContent value="resources" className="h-[calc(100%-60px)]">
              <ResourcePanel
                resourceStore={resourceStore}
                tasks={tasks}
                onTasksUpdate={setTasks}
              />
            </TabsContent>

            <TabsContent value="scenarios">
              {/* ScenarioComparator aqui */}
              <div className="p-4">Scenario Comparator (Coming Soon)</div>
            </TabsContent>

            <TabsContent value="calendars">
              {/* CalendarEditor aqui */}
              <div className="p-4">Calendar Editor (Coming Soon)</div>
            </TabsContent>

            <TabsContent value="constraints">
              {/* ConstraintManager aqui */}
              <div className="p-4">Constraint Manager (Coming Soon)</div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
```

---

## 📊 Dados Mock para Teste

```typescript
// resources.ts
export const mockResources: Resource[] = [
  { id: 'r1', name: 'John Doe', role: 'Frontend Developer', capacity: 8 },
  { id: 'r2', name: 'Jane Smith', role: 'Backend Developer', capacity: 8 },
  { id: 'r3', name: 'Bob Johnson', role: 'UI/UX Designer', capacity: 6 },
  { id: 'r4', name: 'Alice Brown', role: 'Project Manager', capacity: 8 }
];

// allocations.ts
export const mockAllocations: ResourceAllocation[] = [
  {
    id: 'a1',
    resourceId: 'r1',
    taskId: 't1',
    units: 8,
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-01-10')
  },
  {
    id: 'a2',
    resourceId: 'r1',
    taskId: 't2',
    units: 8,
    startDate: new Date('2024-01-08'),
    endDate: new Date('2024-01-15')
  },
  // Isto causará um conflito nos dias 8-10
  {
    id: 'a3',
    resourceId: 'r2',
    taskId: 't3',
    units: 4,
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-01-31')
  }
];
```

---

## 🎯 Próximos Passos

### Para usar o ResourcePanel **agora**:

1. **Copie o exemplo completo** acima
2. **Crie um novo arquivo**: `components/advanced-gantt-demo.tsx`
3. **Cole o código** do exemplo completo
4. **Importe no `app/page.tsx`**:

```typescript
import { AdvancedGanttDemo } from '@/components/advanced-gantt-demo';

export default function Home() {
  return <AdvancedGanttDemo />;
}
```

5. **Execute**: `yarn dev` e acesse `http://localhost:3000`

### Para criar dados mock de teste:

1. **Crie arquivo**: `lib/data/mock-advanced-data.ts`
2. **Adicione os recursos e alocações** do exemplo acima
3. **Importe no seu componente**

---

## 🔍 Verificar Instalação

```bash
# Ver estrutura de stores
ls -la lib/vision-gantt/stores/

# Ver estrutura de hooks
ls -la lib/vision-gantt/hooks/

# Ver estrutura de componentes
ls -la lib/vision-gantt/components/
```

---

## 📚 Referências

- **Types**: `/lib/vision-gantt/types/advanced-features.ts`
- **Utils**: `/lib/vision-gantt/utils/resource-utils.ts`
- **Documentation**: `/ADVANCED_FEATURES.md`

---

## ✨ Funcionalidades do ResourcePanel

### 📊 **Aba Utilization**
- Gráfico de barras com utilização por recurso
- Cores dinâmicas baseadas na utilização:
  - 🔵 Azul: < 60%
  - 🟢 Verde: 60-80%
  - 🟠 Laranja: 80-100%
  - 🔴 Vermelho: > 100% (sobrealocação)

### ⚠️ **Aba Conflicts**
- Lista de conflitos de sobrealocação
- Badges de severidade (Low, Medium, High, Critical)
- Detalhes de horas alocadas vs disponíveis
- Lista de tarefas afetadas

### 👥 **Aba Resources**
- Lista completa de recursos
- Estatísticas por recurso
- Badge de conflitos quando aplicável
- Informações de capacidade e utilização

### ⚡ **Auto-Level Button**
- Nivelamento automático de recursos
- Estratégias: delay_tasks, split_tasks, reduce_allocation
- Prioridades: earliest_start, critical_path, task_priority
- Feedback de resultados (conflitos resolvidos)

---

**Pronto para usar!** 🚀 Todos os componentes estão acessíveis e funcionais.

