

/**
 * Mock data for advanced features testing
 */

import type { Resource } from '@/lib/vision-gantt/types';
import type {
  ResourceAllocation,
  ResourceAvailability,
  Scenario,
  WorkingCalendar,
  TaskConstraint
} from '@/lib/vision-gantt/types/advanced-features';

// ============================================
// RESOURCES
// ============================================

export const mockResources: Resource[] = [
  {
    id: 'r1',
    name: 'John Doe',
    role: 'Frontend Developer',
    capacity: 8,
    costRate: 85,
    costType: 'hour'
  },
  {
    id: 'r2',
    name: 'Jane Smith',
    role: 'Backend Developer',
    capacity: 8,
    costRate: 95,
    costType: 'hour'
  },
  {
    id: 'r3',
    name: 'Bob Johnson',
    role: 'UI/UX Designer',
    capacity: 6,
    costRate: 75,
    costType: 'hour'
  },
  {
    id: 'r4',
    name: 'Alice Brown',
    role: 'Project Manager',
    capacity: 8,
    costRate: 120,
    costType: 'hour'
  },
  {
    id: 'r5',
    name: 'Charlie Wilson',
    role: 'DevOps Engineer',
    capacity: 8,
    costRate: 100,
    costType: 'hour'
  },
  {
    id: 'r6',
    name: 'Diana Martinez',
    role: 'QA Engineer',
    capacity: 8,
    costRate: 70,
    costType: 'hour'
  }
];

// ============================================
// ALLOCATIONS
// ============================================

export const mockAllocations: ResourceAllocation[] = [
  // John Doe - Frontend Developer (sobrealocação intencional)
  {
    id: 'a1',
    resourceId: 'r1',
    taskId: 'task_3',
    units: 8,
    type: 'hours',
    startDate: new Date('2025-09-22'),
    endDate: new Date('2025-09-22')
  },
  {
    id: 'a2',
    resourceId: 'r1',
    taskId: 'task_5',
    units: 6,
    type: 'hours',
    startDate: new Date('2025-09-23'),
    endDate: new Date('2025-09-25')
  },

  // Jane Smith - Backend Developer
  {
    id: 'a3',
    resourceId: 'r2',
    taskId: 'task_2',
    units: 8,
    type: 'hours',
    startDate: new Date('2025-09-23'),
    endDate: new Date('2025-09-27')
  },
  {
    id: 'a4',
    resourceId: 'r2',
    taskId: 'task_14',
    units: 8,
    type: 'hours',
    startDate: new Date('2025-09-28'),
    endDate: new Date('2025-10-07')
  },

  // Bob Johnson - UI/UX Designer
  {
    id: 'a5',
    resourceId: 'r3',
    taskId: 'task_9',
    units: 6,
    type: 'hours',
    startDate: new Date('2025-09-30'),
    endDate: new Date('2025-10-05')
  },
  {
    id: 'a6',
    resourceId: 'r3',
    taskId: 'task_4',
    units: 6,
    type: 'hours',
    startDate: new Date('2025-09-25'),
    endDate: new Date('2025-09-27')
  },

  // Alice Brown - Project Manager (alocação em todas as tarefas)
  {
    id: 'a7',
    resourceId: 'r4',
    taskId: 'task_3',
    units: 2,
    type: 'hours',
    startDate: new Date('2025-09-22'),
    endDate: new Date('2025-09-22')
  },
  {
    id: 'a7b',
    resourceId: 'r4',
    taskId: 'task_2',
    units: 2,
    type: 'hours',
    startDate: new Date('2025-09-23'),
    endDate: new Date('2025-09-27')
  },

  // Charlie Wilson - DevOps
  {
    id: 'a8',
    resourceId: 'r5',
    taskId: 'task_8',
    units: 8,
    type: 'hours',
    startDate: new Date('2025-09-28'),
    endDate: new Date('2025-10-02')
  },
  {
    id: 'a9',
    resourceId: 'r5',
    taskId: 'task_6',
    units: 8,
    type: 'hours',
    startDate: new Date('2025-09-23'),
    endDate: new Date('2025-09-27')
  },

  // Diana Martinez - QA (sobrealocação intencional)
  {
    id: 'a10',
    resourceId: 'r6',
    taskId: 'task_10',
    units: 8,
    type: 'hours',
    startDate: new Date('2025-09-23'),
    endDate: new Date('2025-09-27')
  },
  {
    id: 'a11',
    resourceId: 'r6',
    taskId: 'task_5',
    units: 6,
    type: 'hours',
    startDate: new Date('2025-09-23'),
    endDate: new Date('2025-09-25')
  }
];

// ============================================
// AVAILABILITIES
// ============================================

export const mockAvailabilities: ResourceAvailability[] = [
  // John Doe - férias
  {
    resourceId: 'r1',
    startDate: new Date('2024-02-15'),
    endDate: new Date('2024-02-22'),
    availableUnits: 0,
    reason: 'Vacation'
  },

  // Bob Johnson - trabalho part-time
  {
    resourceId: 'r3',
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-12-31'),
    availableUnits: 6,
    reason: 'Part-time schedule'
  },

  // Alice Brown - compartilhada entre projetos
  {
    resourceId: 'r4',
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-12-31'),
    availableUnits: 4,
    reason: 'Shared across multiple projects'
  }
];

// SCENARIOS
// ============================================

// Simplified - empty for now to avoid complex type matching
export const mockScenarios: Scenario[] = [];

// ============================================
// CALENDARS
// ============================================

export const mockCalendars: WorkingCalendar[] = [
  {
    id: 'calendar-1',
    name: 'Standard Work Calendar',
    description: 'Monday to Friday, 9AM to 5PM',
    timeZone: 'America/New_York',
    defaultStartTime: '09:00',
    defaultEndTime: '17:00',
    workingDays: [
      { dayOfWeek: 1, isWorking: true }, // Monday
      { dayOfWeek: 2, isWorking: true }, // Tuesday
      { dayOfWeek: 3, isWorking: true }, // Wednesday
      { dayOfWeek: 4, isWorking: true }, // Thursday
      { dayOfWeek: 5, isWorking: true }, // Friday
      { dayOfWeek: 0, isWorking: false }, // Sunday
      { dayOfWeek: 6, isWorking: false }  // Saturday
    ],
    holidays: [
      {
        id: 'h1',
        name: 'New Year',
        date: new Date('2024-01-01'),
        recurring: true, type: "public" as const
      },
      {
        id: 'h2',
        name: 'Independence Day',
        date: new Date('2024-07-04'),
        recurring: true, type: "public" as const
      },
      {
        id: 'h3',
        name: 'Christmas',
        date: new Date('2024-12-25'),
        recurring: true, type: "public" as const
      }
    ],
    exceptions: [
      {
        id: 'e1',
        startDate: new Date('2024-12-24'),
        endDate: new Date('2024-12-24'),
        isWorking: false,
        reason: 'Christmas Eve'
      }
    ]
  },
  {
    id: 'calendar-2',
    name: '24/7 Operations',
    description: 'Round the clock operations',
    timeZone: 'America/New_York',
    defaultStartTime: '00:00',
    defaultEndTime: '23:59',
    workingDays: [
      { dayOfWeek: 0, isWorking: true },
      { dayOfWeek: 1, isWorking: true },
      { dayOfWeek: 2, isWorking: true },
      { dayOfWeek: 3, isWorking: true },
      { dayOfWeek: 4, isWorking: true },
      { dayOfWeek: 5, isWorking: true },
      { dayOfWeek: 6, isWorking: true }
    ],
    holidays: [],
    exceptions: []
  }
];

// CONSTRAINTS
// ============================================

// Simplified - empty for now
export const mockConstraints: TaskConstraint[] = [];

// ============================================
// STATISTICS
// ============================================

export const mockAdvancedStats = {
  resources: {
    total: mockResources.length,
    allocated: mockResources.filter(r => 
      mockAllocations.some(a => a.resourceId === r.id)
    ).length,
    available: mockResources.filter(r => 
      !mockAllocations.some(a => a.resourceId === r.id)
    ).length,
    overallocated: 2 // John Doe and Diana Martinez
  },
  allocations: {
    total: mockAllocations.length,
    active: mockAllocations.filter(a => 
      a.endDate >= new Date()
    ).length
  },
  scenarios: {
    total: mockScenarios.length,
    active: mockScenarios.filter(s => s.status === 'active').length,
    draft: mockScenarios.filter(s => s.status === 'draft').length
  },
  constraints: {
    total: mockConstraints.length,
    critical: mockConstraints.filter(c => c.priority >= 9).length,
    high: mockConstraints.filter(c => c.priority >= 7 && c.priority < 9).length
  }
};