
/**
 * Pre-generated mock data export
 */

import { generateMockTasks, generateMockDependencies, generateMockResources } from './generate-mock-data';
import type { Task } from '../vision-gantt/types';

// Helper to flatten hierarchical tasks to flat array with parentId references
function flattenTasksToArray(tasks: Task[]): Task[] {
  const result: Task[] = [];
  
  function processTask(task: Task, parentId?: string) {
    // Create a copy without children for the flat array
    const { children, ...taskWithoutChildren } = task;
    const flatTask: Task = {
      ...taskWithoutChildren,
      parentId: parentId || taskWithoutChildren.parentId
    };
    result.push(flatTask);
    
    // Process children recursively
    if (children && children.length > 0) {
      children.forEach(child => processTask(child, task.id));
    }
  }
  
  tasks.forEach(task => processTask(task));
  return result;
}

// Generate hierarchical tasks and flatten them
const hierarchicalTasks = generateMockTasks();
const flatTasks = flattenTasksToArray(hierarchicalTasks);

// Add MS Project style group headers
const groupHeaders: Task[] = [
  {
    id: 'group-marcos',
    name: '📍 MARCOS',
    wbs: '1',
    startDate: new Date('2025-09-21'),
    endDate: new Date('2025-10-20'),
    duration: 29,
    progress: 62,
    status: 'in_progress',
    isGroup: true,
    level: 0,
    expanded: true
  },
  {
    id: 'group-execucao',
    name: '🔧 EXECUÇÃO',
    wbs: '2',
    startDate: new Date('2025-09-21'),
    endDate: new Date('2025-12-28'),
    duration: 98,
    progress: 45,
    status: 'in_progress',
    isGroup: true,
    level: 0,
    expanded: true
  }
];

// Merge group headers with existing tasks
export const mockTasks = [...groupHeaders, ...flatTasks];
export const mockDependencies = generateMockDependencies();
export const mockResources = generateMockResources();

// Calculate some statistics (now tasks are already flat)
export const projectStats = {
  totalTasks: mockTasks.length,
  totalDependencies: mockDependencies.length,
  totalResources: mockResources.length,
  completedTasks: mockTasks.filter(t => t.status === 'completed').length,
  inProgressTasks: mockTasks.filter(t => t.status === 'in_progress').length,
  notStartedTasks: mockTasks.filter(t => t.status === 'not_started').length
};
