
/**
 * Generate realistic mock data for VisionGantt demo
 */

import type { Task, Dependency, Resource, TaskStatus } from '../vision-gantt/types';
import { addDays, subDays } from 'date-fns';

/**
 * Generate mock resources
 */
export function generateMockResources(): Resource[] {
  return [
    { id: 'res_1', name: 'John Smith', role: 'Project Manager', email: 'john@example.com' },
    { id: 'res_2', name: 'Sarah Johnson', role: 'Lead Developer', email: 'sarah@example.com' },
    { id: 'res_3', name: 'Mike Chen', role: 'Frontend Developer', email: 'mike@example.com' },
    { id: 'res_4', name: 'Emily Davis', role: 'Backend Developer', email: 'emily@example.com' },
    { id: 'res_5', name: 'David Wilson', role: 'UI/UX Designer', email: 'david@example.com' },
    { id: 'res_6', name: 'Lisa Anderson', role: 'QA Engineer', email: 'lisa@example.com' },
    { id: 'res_7', name: 'Tom Martinez', role: 'DevOps Engineer', email: 'tom@example.com' },
    { id: 'res_8', name: 'Anna Lee', role: 'Business Analyst', email: 'anna@example.com' }
  ];
}

/**
 * Generate hierarchical task structure
 */
export function generateMockTasks(): Task[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let taskIdCounter = 1;
  const generateId = () => `task_${taskIdCounter++}`;

  const tasks: Task[] = [];

  // Phase 1: Planning & Design (30 days)
  const phase1Start = subDays(today, 60);
  const phase1: Task = {
    id: generateId(),
    name: 'Phase 1: Planning & Design',
    startDate: phase1Start,
    endDate: addDays(phase1Start, 29),
    duration: 30,
    progress: 100,
    status: 'completed',
    expanded: true,
    children: []
  };

  phase1.children = [
    {
      id: generateId(),
      name: 'Project Kickoff',
      startDate: phase1Start,
      endDate: addDays(phase1Start, 0),
      duration: 1,
      progress: 100,
      status: 'completed',
      parentId: phase1.id,
      isMilestone: true
    },
    {
      id: generateId(),
      name: 'Requirements Gathering',
      startDate: addDays(phase1Start, 1),
      endDate: addDays(phase1Start, 5),
      duration: 5,
      progress: 100,
      status: 'completed',
      parentId: phase1.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Stakeholder Interviews',
          startDate: addDays(phase1Start, 1),
          endDate: addDays(phase1Start, 3),
          duration: 3,
          progress: 100,
          status: 'completed',
          parentId: 'task_3'
        },
        {
          id: generateId(),
          name: 'Document Requirements',
          startDate: addDays(phase1Start, 3),
          endDate: addDays(phase1Start, 5),
          duration: 3,
          progress: 100,
          status: 'completed',
          parentId: 'task_3'
        }
      ]
    },
    {
      id: generateId(),
      name: 'System Architecture Design',
      startDate: addDays(phase1Start, 6),
      endDate: addDays(phase1Start, 15),
      duration: 10,
      progress: 100,
      status: 'completed',
      parentId: phase1.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Database Schema Design',
          startDate: addDays(phase1Start, 6),
          endDate: addDays(phase1Start, 10),
          duration: 5,
          progress: 100,
          status: 'completed',
          parentId: 'task_6'
        },
        {
          id: generateId(),
          name: 'API Design',
          startDate: addDays(phase1Start, 8),
          endDate: addDays(phase1Start, 13),
          duration: 6,
          progress: 100,
          status: 'completed',
          parentId: 'task_6'
        },
        {
          id: generateId(),
          name: 'Security Architecture',
          startDate: addDays(phase1Start, 11),
          endDate: addDays(phase1Start, 15),
          duration: 5,
          progress: 100,
          status: 'completed',
          parentId: 'task_6'
        }
      ]
    },
    {
      id: generateId(),
      name: 'UI/UX Design',
      startDate: addDays(phase1Start, 6),
      endDate: addDays(phase1Start, 20),
      duration: 15,
      progress: 100,
      status: 'completed',
      parentId: phase1.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Wireframing',
          startDate: addDays(phase1Start, 6),
          endDate: addDays(phase1Start, 10),
          duration: 5,
          progress: 100,
          status: 'completed',
          parentId: 'task_10'
        },
        {
          id: generateId(),
          name: 'Visual Design',
          startDate: addDays(phase1Start, 11),
          endDate: addDays(phase1Start, 17),
          duration: 7,
          progress: 100,
          status: 'completed',
          parentId: 'task_10'
        },
        {
          id: generateId(),
          name: 'Design System Creation',
          startDate: addDays(phase1Start, 15),
          endDate: addDays(phase1Start, 20),
          duration: 6,
          progress: 100,
          status: 'completed',
          parentId: 'task_10'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Technical Spec Review',
      startDate: addDays(phase1Start, 21),
      endDate: addDays(phase1Start, 25),
      duration: 5,
      progress: 100,
      status: 'completed',
      parentId: phase1.id
    },
    {
      id: generateId(),
      name: 'Design Approval',
      startDate: addDays(phase1Start, 26),
      endDate: addDays(phase1Start, 29),
      duration: 4,
      progress: 100,
      status: 'completed',
      parentId: phase1.id
    },
    {
      id: generateId(),
      name: 'Phase 1 Complete',
      startDate: addDays(phase1Start, 29),
      endDate: addDays(phase1Start, 29),
      duration: 1,
      progress: 100,
      status: 'completed',
      parentId: phase1.id,
      isMilestone: true
    }
  ];

  tasks.push(phase1);

  // Phase 2: Development (60 days)
  const phase2Start = subDays(today, 30);
  const phase2: Task = {
    id: generateId(),
    name: 'Phase 2: Development',
    startDate: phase2Start,
    endDate: addDays(phase2Start, 59),
    duration: 60,
    progress: 65,
    status: 'in_progress',
    expanded: true,
    children: []
  };

  phase2.children = [
    {
      id: generateId(),
      name: 'Development Kickoff',
      startDate: phase2Start,
      endDate: addDays(phase2Start, 0),
      duration: 1,
      progress: 100,
      status: 'completed',
      parentId: phase2.id,
      isMilestone: true
    },
    {
      id: generateId(),
      name: 'Backend Development',
      startDate: addDays(phase2Start, 1),
      endDate: addDays(phase2Start, 40),
      duration: 40,
      progress: 75,
      status: 'in_progress',
      parentId: phase2.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Database Setup',
          startDate: addDays(phase2Start, 1),
          endDate: addDays(phase2Start, 5),
          duration: 5,
          progress: 100,
          status: 'completed',
          parentId: 'task_19'
        },
        {
          id: generateId(),
          name: 'Authentication Module',
          startDate: addDays(phase2Start, 6),
          endDate: addDays(phase2Start, 12),
          duration: 7,
          progress: 100,
          status: 'completed',
          parentId: 'task_19'
        },
        {
          id: generateId(),
          name: 'User Management API',
          startDate: addDays(phase2Start, 13),
          endDate: addDays(phase2Start, 20),
          duration: 8,
          progress: 100,
          status: 'completed',
          parentId: 'task_19'
        },
        {
          id: generateId(),
          name: 'Core Business Logic',
          startDate: addDays(phase2Start, 21),
          endDate: addDays(phase2Start, 35),
          duration: 15,
          progress: 60,
          status: 'in_progress',
          parentId: 'task_19'
        },
        {
          id: generateId(),
          name: 'API Integration Layer',
          startDate: addDays(phase2Start, 30),
          endDate: addDays(phase2Start, 40),
          duration: 11,
          progress: 40,
          status: 'in_progress',
          parentId: 'task_19'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Frontend Development',
      startDate: addDays(phase2Start, 5),
      endDate: addDays(phase2Start, 45),
      duration: 41,
      progress: 70,
      status: 'in_progress',
      parentId: phase2.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Project Setup & Configuration',
          startDate: addDays(phase2Start, 5),
          endDate: addDays(phase2Start, 7),
          duration: 3,
          progress: 100,
          status: 'completed',
          parentId: 'task_25'
        },
        {
          id: generateId(),
          name: 'Component Library',
          startDate: addDays(phase2Start, 8),
          endDate: addDays(phase2Start, 15),
          duration: 8,
          progress: 100,
          status: 'completed',
          parentId: 'task_25'
        },
        {
          id: generateId(),
          name: 'Authentication UI',
          startDate: addDays(phase2Start, 16),
          endDate: addDays(phase2Start, 22),
          duration: 7,
          progress: 100,
          status: 'completed',
          parentId: 'task_25'
        },
        {
          id: generateId(),
          name: 'Dashboard Implementation',
          startDate: addDays(phase2Start, 23),
          endDate: addDays(phase2Start, 32),
          duration: 10,
          progress: 80,
          status: 'in_progress',
          parentId: 'task_25'
        },
        {
          id: generateId(),
          name: 'Feature Modules',
          startDate: addDays(phase2Start, 28),
          endDate: addDays(phase2Start, 42),
          duration: 15,
          progress: 50,
          status: 'in_progress',
          parentId: 'task_25'
        },
        {
          id: generateId(),
          name: 'Responsive Design Implementation',
          startDate: addDays(phase2Start, 35),
          endDate: addDays(phase2Start, 45),
          duration: 11,
          progress: 30,
          status: 'in_progress',
          parentId: 'task_25'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Integration & Testing',
      startDate: addDays(phase2Start, 35),
      endDate: addDays(phase2Start, 55),
      duration: 21,
      progress: 40,
      status: 'in_progress',
      parentId: phase2.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'API Integration',
          startDate: addDays(phase2Start, 35),
          endDate: addDays(phase2Start, 42),
          duration: 8,
          progress: 70,
          status: 'in_progress',
          parentId: 'task_32'
        },
        {
          id: generateId(),
          name: 'Unit Testing',
          startDate: addDays(phase2Start, 40),
          endDate: addDays(phase2Start, 50),
          duration: 11,
          progress: 40,
          status: 'in_progress',
          parentId: 'task_32'
        },
        {
          id: generateId(),
          name: 'Integration Testing',
          startDate: addDays(phase2Start, 45),
          endDate: addDays(phase2Start, 55),
          duration: 11,
          progress: 20,
          status: 'in_progress',
          parentId: 'task_32'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Code Review & Optimization',
      startDate: addDays(phase2Start, 50),
      endDate: addDays(phase2Start, 59),
      duration: 10,
      progress: 10,
      status: 'not_started',
      parentId: phase2.id
    }
  ];

  tasks.push(phase2);

  // Phase 3: Testing & QA (30 days)
  const phase3Start = addDays(today, 30);
  const phase3: Task = {
    id: generateId(),
    name: 'Phase 3: Testing & QA',
    startDate: phase3Start,
    endDate: addDays(phase3Start, 29),
    duration: 30,
    progress: 0,
    status: 'not_started',
    expanded: true,
    children: []
  };

  phase3.children = [
    {
      id: generateId(),
      name: 'QA Kickoff',
      startDate: phase3Start,
      endDate: addDays(phase3Start, 0),
      duration: 1,
      progress: 0,
      status: 'not_started',
      parentId: phase3.id,
      isMilestone: true
    },
    {
      id: generateId(),
      name: 'Functional Testing',
      startDate: addDays(phase3Start, 1),
      endDate: addDays(phase3Start, 10),
      duration: 10,
      progress: 0,
      status: 'not_started',
      parentId: phase3.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Test Plan Creation',
          startDate: addDays(phase3Start, 1),
          endDate: addDays(phase3Start, 3),
          duration: 3,
          progress: 0,
          status: 'not_started',
          parentId: 'task_39'
        },
        {
          id: generateId(),
          name: 'Test Execution',
          startDate: addDays(phase3Start, 4),
          endDate: addDays(phase3Start, 8),
          duration: 5,
          progress: 0,
          status: 'not_started',
          parentId: 'task_39'
        },
        {
          id: generateId(),
          name: 'Bug Fixes',
          startDate: addDays(phase3Start, 8),
          endDate: addDays(phase3Start, 10),
          duration: 3,
          progress: 0,
          status: 'not_started',
          parentId: 'task_39'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Performance Testing',
      startDate: addDays(phase3Start, 11),
      endDate: addDays(phase3Start, 17),
      duration: 7,
      progress: 0,
      status: 'not_started',
      parentId: phase3.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Load Testing',
          startDate: addDays(phase3Start, 11),
          endDate: addDays(phase3Start, 13),
          duration: 3,
          progress: 0,
          status: 'not_started',
          parentId: 'task_43'
        },
        {
          id: generateId(),
          name: 'Stress Testing',
          startDate: addDays(phase3Start, 14),
          endDate: addDays(phase3Start, 15),
          duration: 2,
          progress: 0,
          status: 'not_started',
          parentId: 'task_43'
        },
        {
          id: generateId(),
          name: 'Performance Optimization',
          startDate: addDays(phase3Start, 15),
          endDate: addDays(phase3Start, 17),
          duration: 3,
          progress: 0,
          status: 'not_started',
          parentId: 'task_43'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Security Testing',
      startDate: addDays(phase3Start, 18),
      endDate: addDays(phase3Start, 22),
      duration: 5,
      progress: 0,
      status: 'not_started',
      parentId: phase3.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Penetration Testing',
          startDate: addDays(phase3Start, 18),
          endDate: addDays(phase3Start, 20),
          duration: 3,
          progress: 0,
          status: 'not_started',
          parentId: 'task_47'
        },
        {
          id: generateId(),
          name: 'Vulnerability Assessment',
          startDate: addDays(phase3Start, 20),
          endDate: addDays(phase3Start, 22),
          duration: 3,
          progress: 0,
          status: 'not_started',
          parentId: 'task_47'
        }
      ]
    },
    {
      id: generateId(),
      name: 'User Acceptance Testing',
      startDate: addDays(phase3Start, 23),
      endDate: addDays(phase3Start, 29),
      duration: 7,
      progress: 0,
      status: 'not_started',
      parentId: phase3.id
    },
    {
      id: generateId(),
      name: 'QA Sign-off',
      startDate: addDays(phase3Start, 29),
      endDate: addDays(phase3Start, 29),
      duration: 1,
      progress: 0,
      status: 'not_started',
      parentId: phase3.id,
      isMilestone: true
    }
  ];

  tasks.push(phase3);

  // Phase 4: Deployment (15 days)
  const phase4Start = addDays(today, 60);
  const phase4: Task = {
    id: generateId(),
    name: 'Phase 4: Deployment & Launch',
    startDate: phase4Start,
    endDate: addDays(phase4Start, 14),
    duration: 15,
    progress: 0,
    status: 'not_started',
    expanded: true,
    children: []
  };

  phase4.children = [
    {
      id: generateId(),
      name: 'Deployment Planning',
      startDate: phase4Start,
      endDate: addDays(phase4Start, 2),
      duration: 3,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id
    },
    {
      id: generateId(),
      name: 'Infrastructure Setup',
      startDate: addDays(phase4Start, 3),
      endDate: addDays(phase4Start, 5),
      duration: 3,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id,
      expanded: true,
      children: [
        {
          id: generateId(),
          name: 'Production Environment Setup',
          startDate: addDays(phase4Start, 3),
          endDate: addDays(phase4Start, 4),
          duration: 2,
          progress: 0,
          status: 'not_started',
          parentId: 'task_54'
        },
        {
          id: generateId(),
          name: 'Database Migration',
          startDate: addDays(phase4Start, 4),
          endDate: addDays(phase4Start, 5),
          duration: 2,
          progress: 0,
          status: 'not_started',
          parentId: 'task_54'
        }
      ]
    },
    {
      id: generateId(),
      name: 'Deployment to Staging',
      startDate: addDays(phase4Start, 6),
      endDate: addDays(phase4Start, 7),
      duration: 2,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id
    },
    {
      id: generateId(),
      name: 'Smoke Testing',
      startDate: addDays(phase4Start, 8),
      endDate: addDays(phase4Start, 9),
      duration: 2,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id
    },
    {
      id: generateId(),
      name: 'Production Deployment',
      startDate: addDays(phase4Start, 10),
      endDate: addDays(phase4Start, 10),
      duration: 1,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id,
      isMilestone: true
    },
    {
      id: generateId(),
      name: 'Post-Deployment Monitoring',
      startDate: addDays(phase4Start, 11),
      endDate: addDays(phase4Start, 14),
      duration: 4,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id
    },
    {
      id: generateId(),
      name: 'Project Launch',
      startDate: addDays(phase4Start, 14),
      endDate: addDays(phase4Start, 14),
      duration: 1,
      progress: 0,
      status: 'not_started',
      parentId: phase4.id,
      isMilestone: true
    }
  ];

  tasks.push(phase4);

  return tasks;
}

/**
 * Generate dependencies between tasks
 */
export function generateMockDependencies(): Dependency[] {
  return [
    // Phase 1 dependencies
    { id: 'dep_1', fromTaskId: 'task_2', toTaskId: 'task_3', type: 'FS' },
    { id: 'dep_2', fromTaskId: 'task_4', toTaskId: 'task_5', type: 'FS' },
    { id: 'dep_3', fromTaskId: 'task_3', toTaskId: 'task_6', type: 'FS' },
    { id: 'dep_4', fromTaskId: 'task_3', toTaskId: 'task_10', type: 'FS' },
    { id: 'dep_5', fromTaskId: 'task_7', toTaskId: 'task_8', type: 'FS' },
    { id: 'dep_6', fromTaskId: 'task_8', toTaskId: 'task_9', type: 'FS' },
    { id: 'dep_7', fromTaskId: 'task_11', toTaskId: 'task_12', type: 'FS' },
    { id: 'dep_8', fromTaskId: 'task_12', toTaskId: 'task_13', type: 'FS' },
    { id: 'dep_9', fromTaskId: 'task_6', toTaskId: 'task_14', type: 'FS' },
    { id: 'dep_10', fromTaskId: 'task_10', toTaskId: 'task_15', type: 'FS' },
    { id: 'dep_11', fromTaskId: 'task_14', toTaskId: 'task_16', type: 'FS' },
    { id: 'dep_12', fromTaskId: 'task_15', toTaskId: 'task_16', type: 'FS' },

    // Phase 1 to Phase 2 dependencies
    { id: 'dep_13', fromTaskId: 'task_16', toTaskId: 'task_18', type: 'FS' },

    // Phase 2 dependencies
    { id: 'dep_14', fromTaskId: 'task_18', toTaskId: 'task_19', type: 'FS' },
    { id: 'dep_15', fromTaskId: 'task_18', toTaskId: 'task_25', type: 'FS' },
    { id: 'dep_16', fromTaskId: 'task_20', toTaskId: 'task_21', type: 'FS' },
    { id: 'dep_17', fromTaskId: 'task_21', toTaskId: 'task_22', type: 'FS' },
    { id: 'dep_18', fromTaskId: 'task_22', toTaskId: 'task_23', type: 'FS' },
    { id: 'dep_19', fromTaskId: 'task_23', toTaskId: 'task_24', type: 'SS', lag: 5 },
    { id: 'dep_20', fromTaskId: 'task_26', toTaskId: 'task_27', type: 'FS' },
    { id: 'dep_21', fromTaskId: 'task_27', toTaskId: 'task_28', type: 'FS' },
    { id: 'dep_22', fromTaskId: 'task_21', toTaskId: 'task_28', type: 'FS' },
    { id: 'dep_23', fromTaskId: 'task_28', toTaskId: 'task_29', type: 'FS' },
    { id: 'dep_24', fromTaskId: 'task_29', toTaskId: 'task_30', type: 'FS' },
    { id: 'dep_25', fromTaskId: 'task_29', toTaskId: 'task_31', type: 'SS', lag: 5 },
    { id: 'dep_26', fromTaskId: 'task_23', toTaskId: 'task_33', type: 'FS' },
    { id: 'dep_27', fromTaskId: 'task_30', toTaskId: 'task_33', type: 'FS' },
    { id: 'dep_28', fromTaskId: 'task_33', toTaskId: 'task_34', type: 'SS', lag: 3 },
    { id: 'dep_29', fromTaskId: 'task_34', toTaskId: 'task_35', type: 'FS' },
    { id: 'dep_30', fromTaskId: 'task_24', toTaskId: 'task_36', type: 'FS' },
    { id: 'dep_31', fromTaskId: 'task_31', toTaskId: 'task_36', type: 'FS' },

    // Phase 2 to Phase 3 dependencies
    { id: 'dep_32', fromTaskId: 'task_36', toTaskId: 'task_38', type: 'FS' },

    // Phase 3 dependencies
    { id: 'dep_33', fromTaskId: 'task_38', toTaskId: 'task_39', type: 'FS' },
    { id: 'dep_34', fromTaskId: 'task_40', toTaskId: 'task_41', type: 'FS' },
    { id: 'dep_35', fromTaskId: 'task_41', toTaskId: 'task_42', type: 'FS' },
    { id: 'dep_36', fromTaskId: 'task_39', toTaskId: 'task_43', type: 'FS' },
    { id: 'dep_37', fromTaskId: 'task_44', toTaskId: 'task_45', type: 'FS' },
    { id: 'dep_38', fromTaskId: 'task_45', toTaskId: 'task_46', type: 'FS' },
    { id: 'dep_39', fromTaskId: 'task_43', toTaskId: 'task_47', type: 'FS' },
    { id: 'dep_40', fromTaskId: 'task_48', toTaskId: 'task_49', type: 'FS' },
    { id: 'dep_41', fromTaskId: 'task_47', toTaskId: 'task_50', type: 'FS' },
    { id: 'dep_42', fromTaskId: 'task_50', toTaskId: 'task_51', type: 'FS' },

    // Phase 3 to Phase 4 dependencies
    { id: 'dep_43', fromTaskId: 'task_51', toTaskId: 'task_53', type: 'FS' },

    // Phase 4 dependencies
    { id: 'dep_44', fromTaskId: 'task_53', toTaskId: 'task_54', type: 'FS' },
    { id: 'dep_45', fromTaskId: 'task_55', toTaskId: 'task_56', type: 'FS' },
    { id: 'dep_46', fromTaskId: 'task_54', toTaskId: 'task_57', type: 'FS' },
    { id: 'dep_47', fromTaskId: 'task_57', toTaskId: 'task_58', type: 'FS' },
    { id: 'dep_48', fromTaskId: 'task_58', toTaskId: 'task_59', type: 'FS' },
    { id: 'dep_49', fromTaskId: 'task_59', toTaskId: 'task_60', type: 'FS' },
    { id: 'dep_50', fromTaskId: 'task_60', toTaskId: 'task_61', type: 'FS' }
  ];
}

/**
 * Calculate predecessors and successors for each task based on dependencies
 */
export function calculatePredecessorsAndSuccessors(
  tasks: Task[],
  dependencies: Dependency[]
): Task[] {
  // Create maps for quick lookup
  const predecessorsMap: Record<string, string[]> = {};
  const successorsMap: Record<string, string[]> = {};

  // Build maps from dependencies
  dependencies.forEach(dep => {
    // Add to successors map (fromTask -> toTask)
    if (!successorsMap[dep.fromTaskId]) {
      successorsMap[dep.fromTaskId] = [];
    }
    successorsMap[dep.fromTaskId].push(dep.toTaskId);

    // Add to predecessors map (toTask <- fromTask)
    if (!predecessorsMap[dep.toTaskId]) {
      predecessorsMap[dep.toTaskId] = [];
    }
    predecessorsMap[dep.toTaskId].push(dep.fromTaskId);
  });

  // Update tasks with predecessor and successor information
  return tasks.map(task => ({
    ...task,
    predecessors: predecessorsMap[task.id] || [],
    successors: successorsMap[task.id] || []
  }));
}
