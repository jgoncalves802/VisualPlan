

/**
 * Advanced Gantt Demo - Demonstrates advanced features
 */

'use client';

import React, { useState } from 'react';
import { GanttChart } from '@/lib/vision-gantt';
import { ResourcePanel } from '@/lib/vision-gantt/components/resource-panel';
import { ScenarioComparator } from '@/lib/vision-gantt/components/scenario-comparator';
import { CalendarEditor } from '@/lib/vision-gantt/components/calendar-editor';
import { ConstraintManager } from '@/lib/vision-gantt/components/constraint-manager';
import { useAdvancedStores } from '@/lib/vision-gantt/hooks/use-advanced-stores';
import type { Task, Dependency, ViewPreset } from '@/lib/vision-gantt/types';
import { mockTasks, mockDependencies } from '@/lib/data/mock-data';
import {
  mockResources,
  mockAllocations,
  mockAvailabilities,
  mockScenarios,
  mockCalendars,
  mockConstraints,
  mockAdvancedStats
} from '@/lib/data/mock-advanced-data';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Calendar, 
  AlertTriangle, 
  Layers, 
  TrendingUp 
} from 'lucide-react';

export function AdvancedGanttDemo() {
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [dependencies] = useState<Dependency[]>(mockDependencies);
  const [viewPreset, setViewPreset] = useState<ViewPreset>('week');

  // Initialize advanced stores
  const {
    resourceStore,
    scenarioStore,
    calendarStore,
    constraintStore,
    conflicts,
    scenarios,
    violations
  } = useAdvancedStores({
    resources: mockResources,
    allocations: mockAllocations,
    availabilities: mockAvailabilities,
    scenarios: mockScenarios,
    calendars: mockCalendars,
    constraints: mockConstraints
  });

  const handleTaskUpdate = (task: Task) => {
    const index = tasks.findIndex(t => t.id === task.id);
    if (index !== -1) {
      const newTasks = [...tasks];
      newTasks[index] = task;
      setTasks(newTasks);
    }
  };

  const handleTasksUpdate = (updatedTasks: Task[]) => {
    setTasks(updatedTasks);
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Advanced Gantt Chart Demo
            </h1>
            <p className="text-sm text-gray-600 mt-1">
              Complete project management with resources, scenarios, and constraints
            </p>
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-4">
            <Card className="px-4 py-2">
              <div className="flex items-center gap-2">
                <Users className="text-blue-600" size={16} />
                <div>
                  <p className="text-xs text-gray-600">Resources</p>
                  <p className="text-lg font-bold">{mockAdvancedStats.resources.total}</p>
                </div>
              </div>
            </Card>

            <Card className="px-4 py-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="text-orange-600" size={16} />
                <div>
                  <p className="text-xs text-gray-600">Conflicts</p>
                  <p className="text-lg font-bold">{conflicts.length}</p>
                </div>
              </div>
            </Card>

            <Card className="px-4 py-2">
              <div className="flex items-center gap-2">
                <Layers className="text-purple-600" size={16} />
                <div>
                  <p className="text-xs text-gray-600">Scenarios</p>
                  <p className="text-lg font-bold">{scenarios.length}</p>
                </div>
              </div>
            </Card>

            <Card className="px-4 py-2">
              <div className="flex items-center gap-2">
                <Calendar className="text-green-600" size={16} />
                <div>
                  <p className="text-xs text-gray-600">Violations</p>
                  <p className="text-lg font-bold">{violations.length}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Gantt Chart - 65% */}
        <div className="w-[65%] border-r border-gray-200 bg-white">
          <GanttChart
            tasks={tasks}
            dependencies={dependencies}
            viewPreset={viewPreset}
            height={window.innerHeight - 100}
            gridWidth={400}
            enableDragDrop={true}
            enableResize={true}
            onTaskUpdate={handleTaskUpdate}
            onViewPresetChange={setViewPreset}
          />
        </div>

        {/* Advanced Features Panel - 35% */}
        <div className="w-[35%] bg-white">
          <Tabs defaultValue="resources" className="h-full flex flex-col">
            <div className="border-b border-gray-200">
              <TabsList className="w-full justify-start p-2 bg-gray-50">
                <TabsTrigger value="resources" className="flex items-center gap-2">
                  <Users size={16} />
                  <span>Resources</span>
                  {conflicts.length > 0 && (
                    <Badge variant="destructive" className="ml-1 h-5 px-1.5 text-xs">
                      {conflicts.length}
                    </Badge>
                  )}
                </TabsTrigger>
                
                <TabsTrigger value="scenarios" className="flex items-center gap-2">
                  <Layers size={16} />
                  <span>Scenarios</span>
                  <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                    {scenarios.length}
                  </Badge>
                </TabsTrigger>
                
                <TabsTrigger value="calendars" className="flex items-center gap-2">
                  <Calendar size={16} />
                  <span>Calendars</span>
                </TabsTrigger>
                
                <TabsTrigger value="constraints" className="flex items-center gap-2">
                  <AlertTriangle size={16} />
                  <span>Constraints</span>
                  {violations.length > 0 && (
                    <Badge variant="destructive" className="ml-1 h-5 px-1.5 text-xs">
                      {violations.length}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-hidden">
              <TabsContent value="resources" className="h-full m-0">
                <ResourcePanel
                  resourceStore={resourceStore}
                  tasks={tasks}
                  onTasksUpdate={handleTasksUpdate}
                />
              </TabsContent>

              <TabsContent value="scenarios" className="h-full m-0">
                <ScenarioComparator
                  scenarioStore={scenarioStore}
                  tasks={tasks}
                  dependencies={dependencies}
                  onTasksUpdate={handleTasksUpdate}
                />
              </TabsContent>

              <TabsContent value="calendars" className="h-full m-0">
                <CalendarEditor calendarStore={calendarStore} />
              </TabsContent>

              <TabsContent value="constraints" className="h-full m-0">
                <ConstraintManager
                  constraintStore={constraintStore}
                  calendarStore={calendarStore}
                  tasks={tasks}
                  onTasksUpdate={handleTasksUpdate}
                />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

