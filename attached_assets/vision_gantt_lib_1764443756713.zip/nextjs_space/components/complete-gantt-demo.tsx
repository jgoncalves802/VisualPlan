
/**
 * CompleteGanttDemo - Full-featured Gantt chart demonstration
 * Shows ALL capabilities of VisionGantt library
 */

'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GanttChart } from '@/lib/vision-gantt';
import { ResourcePanel } from '@/lib/vision-gantt/components/resource-panel';
import { ScenarioComparator } from '@/lib/vision-gantt/components/scenario-comparator';
import { CalendarEditor } from '@/lib/vision-gantt/components/calendar-editor';
import { ConstraintManager } from '@/lib/vision-gantt/components/constraint-manager';
import { FiltersPanel, applyFilters, type TaskFilters } from '@/lib/vision-gantt/components/filters-panel';
import { AnalyticsDashboard } from '@/lib/vision-gantt/components/analytics-dashboard';
import { useAdvancedStores } from '@/lib/vision-gantt/hooks/use-advanced-stores';
import { useKeyboardShortcuts, getShortcutLabel, type KeyboardShortcut } from '@/lib/vision-gantt/hooks/use-keyboard-shortcuts';
import { useUndoRedo } from '@/lib/vision-gantt/hooks/use-undo-redo';
import { calculateCriticalPath } from '@/lib/vision-gantt/utils/critical-path-utils';
import { exportToCSV, exportToJSON, exportToMSProjectXML, downloadFile } from '@/lib/vision-gantt/utils/export-utils';
import type { Task, Dependency, ViewPreset } from '@/lib/vision-gantt/types';
import { mockTasks, mockDependencies } from '@/lib/data/mock-data';
import {
  mockResources,
  mockAllocations,
  mockCalendars,
  mockConstraints
} from '@/lib/data/mock-advanced-data';
import {
  Activity,
  BarChart3,
  Calendar,
  AlertTriangle,
  Layers,
  Download,
  Undo2,
  Redo2,
  Keyboard,
  Filter,
  LineChart,
  Settings,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

export function CompleteGanttDemo() {
  // State management
  const {
    state: tasks,
    set: setTasks,
    undo,
    redo,
    canUndo,
    canRedo
  } = useUndoRedo<Task[]>(mockTasks);

  const [dependencies, setDependencies] = useState<Dependency[]>(mockDependencies);
  const [showKeyboardShortcuts, setShowKeyboardShortcuts] = useState(false);
  const [activeTab, setActiveTab] = useState('analytics');

  // Filters
  const [filters, setFilters] = useState<TaskFilters>({
    searchTerm: '',
    statuses: [],
    dateRange: {},
    progressRange: { min: 0, max: 100 },
    showCriticalOnly: false,
    showMilestones: false
  });

  // Advanced features stores
  const {
    resourceStore,
    scenarioStore,
    calendarStore,
    constraintStore,
    resources,
    conflicts,
    scenarios,
    calendars,
    constraints,
    violations
  } = useAdvancedStores({
    resources: mockResources,
    allocations: mockAllocations,
    calendars: mockCalendars,
    constraints: mockConstraints
  });

  // Calculate critical path
  const criticalPathSchedule = calculateCriticalPath(tasks, dependencies);
  const criticalPathIds = criticalPathSchedule
    .filter(s => s.isCritical)
    .map(s => s.taskId);

  // Apply filters
  const filteredTasks = applyFilters(tasks, filters);

  // Handle task updates
  const handleTasksUpdate = useCallback((newTasks: Task[]) => {
    setTasks(newTasks);
  }, [setTasks]);

  // Keyboard shortcuts
  const shortcuts: KeyboardShortcut[] = [
    {
      key: 'z',
      ctrl: true,
      action: undo,
      description: 'Undo last change'
    },
    {
      key: 'y',
      ctrl: true,
      action: redo,
      description: 'Redo last change'
    },
    {
      key: 's',
      ctrl: true,
      action: () => {
        const csv = exportToCSV(tasks);
        downloadFile(csv, 'gantt-export.csv', 'text/csv');
        toast.success('Exported to CSV');
      },
      description: 'Export to CSV'
    },
    {
      key: 'k',
      ctrl: true,
      action: () => setShowKeyboardShortcuts(true),
      description: 'Show keyboard shortcuts'
    }
  ];

  useKeyboardShortcuts(shortcuts, true);

  // Export functions
  const handleExportCSV = () => {
    const csv = exportToCSV(tasks);
    downloadFile(csv, `gantt-export-${new Date().toISOString().split('T')[0]}.csv`, 'text/csv');
    toast.success('Exported to CSV successfully');
  };

  const handleExportJSON = () => {
    const json = exportToJSON(tasks, dependencies);
    downloadFile(json, `gantt-export-${new Date().toISOString().split('T')[0]}.json`, 'application/json');
    toast.success('Exported to JSON successfully');
  };

  const handleExportXML = () => {
    const xml = exportToMSProjectXML(tasks, dependencies);
    downloadFile(xml, `gantt-export-${new Date().toISOString().split('T')[0]}.xml`, 'application/xml');
    toast.success('Exported to MS Project XML successfully');
  };

  // Statistics - prevent hydration mismatch
  const [isClient, setIsClient] = useState(false);
  
  useEffect(() => {
    setIsClient(true);
  }, []);

  const stats = {
    totalTasks: tasks.length,
    filteredTasks: filteredTasks.length,
    resources: isClient ? resources.length : 0,
    conflicts: isClient ? conflicts.length : 0,
    scenarios: isClient ? scenarios.length : 0,
    violations: isClient ? violations.length : 0,
    criticalTasks: isClient ? criticalPathIds.length : 0
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">VisionGantt Complete Demo</h1>
            <p className="text-sm text-gray-600">
              Full-featured project management with all advanced capabilities
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Undo/Redo */}
            <Button
              variant="outline"
              size="sm"
              onClick={undo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
            >
              <Undo2 size={16} />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={redo}
              disabled={!canRedo}
              title="Redo (Ctrl+Y)"
            >
              <Redo2 size={16} />
            </Button>

            {/* Export */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Download size={16} className="mr-1" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Export Formats</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleExportCSV}>
                  CSV (Ctrl+S)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportJSON}>
                  JSON
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportXML}>
                  MS Project XML
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Keyboard Shortcuts */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowKeyboardShortcuts(true)}
              title="Keyboard Shortcuts (Ctrl+K)"
            >
              <Keyboard size={16} />
            </Button>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-7 gap-3">
          <Card className="p-3">
            <div className="flex items-center gap-2">
              <Activity className="text-blue-600" size={16} />
              <div>
                <p className="text-xs text-gray-600">Tasks</p>
                <p className="text-lg font-bold text-gray-900">{stats.filteredTasks}/{stats.totalTasks}</p>
              </div>
            </div>
          </Card>

          <Card className="p-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="text-purple-600" size={16} />
              <div>
                <p className="text-xs text-gray-600">Resources</p>
                <p className="text-lg font-bold text-gray-900">{stats.resources}</p>
              </div>
            </div>
          </Card>

          <Card className="p-3 bg-red-50 border-red-200">
            <div className="flex items-center gap-2">
              <AlertTriangle className="text-red-600" size={16} />
              <div>
                <p className="text-xs text-red-700">Conflicts</p>
                <p className="text-lg font-bold text-red-900">{stats.conflicts}</p>
              </div>
            </div>
          </Card>

          <Card className="p-3">
            <div className="flex items-center gap-2">
              <Layers className="text-indigo-600" size={16} />
              <div>
                <p className="text-xs text-gray-600">Scenarios</p>
                <p className="text-lg font-bold text-gray-900">{stats.scenarios}</p>
              </div>
            </div>
          </Card>

          <Card className="p-3">
            <div className="flex items-center gap-2">
              <Calendar className="text-green-600" size={16} />
              <div>
                <p className="text-xs text-gray-600">Calendars</p>
                <p className="text-lg font-bold text-gray-900">{calendars.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-3 bg-orange-50 border-orange-200">
            <div className="flex items-center gap-2">
              <Settings className="text-orange-600" size={16} />
              <div>
                <p className="text-xs text-orange-700">Violations</p>
                <p className="text-lg font-bold text-orange-900">{stats.violations}</p>
              </div>
            </div>
          </Card>

          <Card className="p-3 bg-red-50 border-red-200">
            <div className="flex items-center gap-2">
              <LineChart className="text-red-600" size={16} />
              <div>
                <p className="text-xs text-red-700">Critical</p>
                <p className="text-lg font-bold text-red-900">{stats.criticalTasks}</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Gantt Chart */}
        <div className="flex-1 flex flex-col border-r border-gray-200">
          {/* Filters */}
          <div className="p-4 border-b border-gray-200">
            <FiltersPanel
              filters={filters}
              onFiltersChange={setFilters}
              tasks={tasks}
            />
          </div>

          {/* Gantt */}
          <div className="flex-1 overflow-hidden">
            <GanttChart
              tasks={filteredTasks}
              dependencies={dependencies}
              criticalPathIds={criticalPathIds}
              violationTaskIds={violations.map(v => v.taskId)}
              conflictTaskIds={conflicts.map(c => c.resourceId)}
            />
          </div>
        </div>

        {/* Right: Advanced Features */}
        <div className="w-[600px] bg-white overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <TabsList className="px-4 pt-4">
              <TabsTrigger value="analytics">
                <LineChart size={14} className="mr-1" />
                Analytics
              </TabsTrigger>
              <TabsTrigger value="resources">
                <BarChart3 size={14} className="mr-1" />
                Resources
              </TabsTrigger>
              <TabsTrigger value="scenarios">
                <Layers size={14} className="mr-1" />
                Scenarios
              </TabsTrigger>
              <TabsTrigger value="calendars">
                <Calendar size={14} className="mr-1" />
                Calendars
              </TabsTrigger>
              <TabsTrigger value="constraints">
                <AlertTriangle size={14} className="mr-1" />
                Constraints
              </TabsTrigger>
            </TabsList>

            <div className="flex-1 overflow-hidden">
              <TabsContent value="analytics" className="h-full m-0 p-4 overflow-auto">
                <AnalyticsDashboard
                  tasks={tasks}
                  dependencies={dependencies}
                  criticalPathIds={criticalPathIds}
                />
              </TabsContent>

              <TabsContent value="resources" className="h-full m-0">
                <ResourcePanel
                  resourceStore={resourceStore}
                  tasks={tasks}
                  onTasksUpdate={handleTasksUpdate}
                />
              </TabsContent>

              <TabsContent value="scenarios" className="h-full m-0">
                <ScenarioComparator
                  scenarioStore={scenarioStore}
                  tasks={tasks}
                  dependencies={dependencies}
                  onTasksUpdate={handleTasksUpdate}
                />
              </TabsContent>

              <TabsContent value="calendars" className="h-full m-0">
                <CalendarEditor calendarStore={calendarStore} />
              </TabsContent>

              <TabsContent value="constraints" className="h-full m-0">
                <ConstraintManager
                  constraintStore={constraintStore}
                  calendarStore={calendarStore}
                  tasks={tasks}
                  onTasksUpdate={handleTasksUpdate}
                />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>

      {/* Keyboard Shortcuts Dialog */}
      <Dialog open={showKeyboardShortcuts} onOpenChange={setShowKeyboardShortcuts}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
            <DialogDescription>
              Use these shortcuts for faster navigation and actions
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            {shortcuts.map((shortcut, index) => (
              <div key={index} className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-sm text-gray-700">{shortcut.description}</span>
                <Badge variant="outline" className="font-mono">
                  {getShortcutLabel(shortcut)}
                </Badge>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

