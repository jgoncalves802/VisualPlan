
/**
 * FullFeaturesDemo - Complete demonstration with all VisionGantt capabilities
 * Includes toolbar with all features, predecessor/successor columns, and advanced functionality
 */

'use client';

import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { GanttChart } from '@/lib/vision-gantt';
import type { Task, Dependency, ViewPreset } from '@/lib/vision-gantt/types';
import type { Scenario, WorkingCalendar, ResourceAllocation } from '@/lib/vision-gantt/types/advanced-features';
import { mockTasks, mockDependencies } from '@/lib/data/mock-data';
import { calculatePredecessorsAndSuccessors } from '@/lib/data/generate-mock-data';
import { ProjectStats } from './project-stats';
import { TaskDetailsPanel } from './task-details-panel';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  ZoomIn, 
  ZoomOut, 
  Download, 
  Upload, 
  RefreshCw, 
  Save,
  FileJson,
  FileText,
  FileSpreadsheet,
  Settings,
  Calendar,
  Users,
  AlertCircle,
  GitCompare,
  PlayCircle,
  PauseCircle,
  StopCircle,
  Maximize2,
  Minimize2,
  Grid3x3,
  Filter,
  Search,
  X
} from 'lucide-react';
import { useAdvancedStores } from '@/lib/vision-gantt/hooks/use-advanced-stores';
import { 
  mockResources, 
  mockAllocations, 
  mockScenarios, 
  mockCalendars, 
  mockConstraints 
} from '@/lib/data/mock-advanced-data';
import { ResourcePanel } from '@/lib/vision-gantt/components/resource-panel';
import { ResourceUsageView } from '@/lib/vision-gantt/components/resource-usage-view';
import { ScenarioComparator } from '@/lib/vision-gantt/components/scenario-comparator';
import { CalendarEditor } from '@/lib/vision-gantt/components/calendar-editor';
import { ConstraintManager } from '@/lib/vision-gantt/components/constraint-manager';
import { toast } from 'sonner';

export function FullFeaturesDemo() {
  // Generate mock data with predecessors and successors
  const { tasks: initialTasks, dependencies: initialDependencies } = useMemo(() => {
    const tasksWithPredSucc = calculatePredecessorsAndSuccessors(mockTasks, mockDependencies);
    return { tasks: tasksWithPredSucc, dependencies: mockDependencies };
  }, []);

  const [tasks, setTasks] = useState(initialTasks);
  const [dependencies, setDependencies] = useState(initialDependencies);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [viewPreset, setViewPreset] = useState<ViewPreset>('month');
  const [showAdvancedPanel, setShowAdvancedPanel] = useState(false);
  const [showResourcePanel, setShowResourcePanel] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Advanced stores
  const stores = useAdvancedStores({
    resources: mockResources,
    allocations: mockAllocations,
    scenarios: mockScenarios,
    calendars: mockCalendars,
    constraints: mockConstraints
  });

  // Calculate project stats
  const projectStats = useMemo(() => {
    const totalTasks = tasks.length;
    const completed = tasks.filter(t => t.status === 'completed').length;
    const inProgress = tasks.filter(t => t.status === 'in_progress').length;
    const notStarted = tasks.filter(t => t.status === 'not_started').length;

    return {
      totalTasks,
      completed,
      inProgress,
      notStarted,
      dependencies: dependencies.length
    };
  }, [tasks, dependencies]);

  const handleTaskUpdate = useCallback((task: Task) => {
    console.log('Task updated:', task);
    setTasks(prev => prev.map(t => t.id === task.id ? task : t));
    toast.success('Task updated successfully');
  }, []);

  const handleTaskClick = useCallback((task: Task) => {
    setSelectedTask(task);
  }, []);

  const handleDependencyCreate = useCallback((dependency: Dependency) => {
    console.log('Dependency created:', dependency);
    setDependencies(prev => [...prev, dependency]);
    
    // Recalculate predecessors and successors
    const updatedTasks = calculatePredecessorsAndSuccessors(tasks, [...dependencies, dependency]);
    setTasks(updatedTasks);
    
    toast.success('Dependency created successfully');
  }, [tasks, dependencies]);

  const handleViewPresetChange = useCallback((preset: ViewPreset) => {
    setViewPreset(preset);
  }, []);

  // Export functions
  const handleExportJSON = useCallback(() => {
    const data = { tasks, dependencies };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `project_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Project exported as JSON');
  }, [tasks, dependencies]);

  const handleExportCSV = useCallback(() => {
    const headers = ['WBS', 'Task Name', 'Start Date', 'End Date', 'Duration', 'Status', 'Progress', 'Predecessors', 'Successors'];
    const rows = tasks.map(t => [
      t.wbs || '',
      t.name || '',
      t.startDate?.toISOString().split('T')[0] || '',
      t.endDate?.toISOString().split('T')[0] || '',
      t.duration?.toString() || '',
      t.status || '',
      `${t.progress || 0}%`,
      ((t as any).predecessors || []).join(';'),
      ((t as any).successors || []).join(';')
    ]);
    
    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `project_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Project exported as CSV');
  }, [tasks]);

  const handleReset = useCallback(() => {
    const tasksWithPredSucc = calculatePredecessorsAndSuccessors(mockTasks, mockDependencies);
    setTasks(tasksWithPredSucc);
    setDependencies(mockDependencies);
    setSelectedTask(null);
    toast.info('Project data reset to initial state');
  }, []);

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-3 items-center justify-between">
          {/* Left: Main actions */}
          <div className="flex flex-wrap gap-2">
            <Button 
              variant="default" 
              size="sm"
              onClick={() => setShowResourcePanel(!showResourcePanel)}
            >
              <Users className="w-4 h-4 mr-2" />
              {showResourcePanel ? 'Hide' : 'Show'} Resources
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowAdvancedPanel(!showAdvancedPanel)}
            >
              <Settings className="w-4 h-4 mr-2" />
              {showAdvancedPanel ? 'Hide' : 'Show'} Advanced Features
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsFullscreen(!isFullscreen)}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4 mr-2" /> : <Maximize2 className="w-4 h-4 mr-2" />}
              {isFullscreen ? 'Exit' : 'Fullscreen'}
            </Button>

            <div className="h-6 w-px bg-gray-300" />

            <Button 
              variant="outline" 
              size="sm"
              onClick={handleExportJSON}
            >
              <FileJson className="w-4 h-4 mr-2" />
              Export JSON
            </Button>

            <Button 
              variant="outline" 
              size="sm"
              onClick={handleExportCSV}
            >
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Export CSV
            </Button>

            <Button 
              variant="outline" 
              size="sm"
              onClick={handleReset}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Reset Data
            </Button>
          </div>

          {/* Right: Stats */}
          <div className="flex gap-3 items-center">
            <Badge variant="secondary">
              <Grid3x3 className="w-3 h-3 mr-1" />
              {projectStats.totalTasks} Tasks
            </Badge>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              {projectStats.completed} Completed
            </Badge>
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              {projectStats.inProgress} In Progress
            </Badge>
            <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
              {projectStats.notStarted} Not Started
            </Badge>
            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
              {projectStats.dependencies} Dependencies
            </Badge>
          </div>
        </div>
      </Card>

      {/* Main Content */}
      <div className={`${isFullscreen ? 'fixed inset-0 z-50 bg-white p-4' : ''}`}>
        <div className={`flex flex-col gap-4 ${isFullscreen ? 'h-full' : ''}`}>
          {/* Resource Usage View - Above Gantt Chart */}
          <div 
            className={`w-full transition-all duration-300 ease-in-out ${
              showResourcePanel 
                ? 'max-h-[800px] opacity-100' 
                : 'max-h-0 opacity-0 overflow-hidden'
            }`}
          >
            {showResourcePanel && (
              <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-gray-800">Resource Management</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowResourcePanel(false)}
                    className="h-7 w-7 p-0"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <ResourceUsageView 
                  resourceStore={stores.resourceStore}
                  tasks={tasks}
                />
              </div>
            )}
          </div>

          {/* Gantt Chart */}
          <div className="w-full bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
            <GanttChart
              tasks={tasks}
              dependencies={dependencies}
              viewPreset={viewPreset}
              height={isFullscreen ? window.innerHeight - 150 : 700}
              gridWidth={550}
              enableDragDrop={true}
              enableResize={true}
              enableDependencyCreation={true}
              onTaskUpdate={handleTaskUpdate}
              onTaskClick={handleTaskClick}
              onDependencyCreate={handleDependencyCreate}
              onViewPresetChange={handleViewPresetChange}
            />
          </div>

          {/* Advanced Features Panel - Below Gantt Chart */}
          <div 
            className={`w-full bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden transition-all duration-300 ease-in-out ${
              showAdvancedPanel 
                ? 'max-h-[600px] opacity-100' 
                : 'max-h-0 opacity-0 border-0'
            }`}
          >
            {showAdvancedPanel && (
              <Tabs defaultValue="resources" className="h-full flex flex-col">
                <div className="border-b bg-gray-50 px-4 py-3">
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-lg font-semibold text-gray-800">Advanced Features</h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowAdvancedPanel(false)}
                      className="h-7 w-7 p-0"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <TabsList className="grid w-full grid-cols-4 bg-white">
                    <TabsTrigger value="resources" className="text-xs">
                      <Users className="w-3 h-3 mr-1" />
                      Resources
                    </TabsTrigger>
                    <TabsTrigger value="scenarios" className="text-xs">
                      <GitCompare className="w-3 h-3 mr-1" />
                      Scenarios
                    </TabsTrigger>
                    <TabsTrigger value="calendars" className="text-xs">
                      <Calendar className="w-3 h-3 mr-1" />
                      Calendars
                    </TabsTrigger>
                    <TabsTrigger value="constraints" className="text-xs">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Constraints
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="flex-1 overflow-auto p-4 max-h-[500px]">
                  <TabsContent value="resources" className="mt-0">
                    <ResourcePanel
                      resourceStore={stores.resourceStore}
                      tasks={tasks}
                      onTasksUpdate={(updatedTasks) => {
                        setTasks(updatedTasks);
                        toast.success('Tasks updated from resource leveling');
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="scenarios" className="mt-0">
                    <ScenarioComparator
                      scenarioStore={stores.scenarioStore}
                      tasks={tasks}
                      dependencies={dependencies}
                      onTasksUpdate={(updatedTasks) => {
                        setTasks(updatedTasks);
                        toast.success('Tasks updated from scenario');
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="calendars" className="mt-0">
                    <CalendarEditor
                      calendarStore={stores.calendarStore}
                    />
                  </TabsContent>

                  <TabsContent value="constraints" className="mt-0">
                    <ConstraintManager
                      constraintStore={stores.constraintStore}
                      calendarStore={stores.calendarStore}
                      tasks={tasks}
                      onTasksUpdate={(updatedTasks) => {
                        setTasks(updatedTasks);
                        toast.success('Tasks updated');
                      }}
                    />
                  </TabsContent>
                </div>
              </Tabs>
            )}
          </div>
        </div>
      </div>

      {/* Task Details Panel */}
      {selectedTask && (
        <TaskDetailsPanel
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
        />
      )}

      {/* Feature Highlights */}
      {!isFullscreen && (
        <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            🎯 VisionGantt Library - Complete Feature Set
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-white/80 backdrop-blur-sm rounded-lg p-4 border border-blue-100">
              <h4 className="font-semibold text-blue-800 mb-2">📊 Core Features</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                <li>✓ WBS Auto-Numbering with Indentation</li>
                <li>✓ Predecessor/Successor Tracking</li>
                <li>✓ Resizable Columns</li>
                <li>✓ Drag & Drop Tasks</li>
                <li>✓ Task Dependencies (FS/SS/FF/SF)</li>
                <li>✓ Parent Task Protection</li>
              </ul>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-lg p-4 border border-purple-100">
              <h4 className="font-semibold text-purple-800 mb-2">🚀 Advanced Features</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                <li>✓ Resource Management</li>
                <li>✓ Scenario Comparison</li>
                <li>✓ Working Calendars</li>
                <li>✓ Constraint Validation</li>
                <li>✓ Critical Path Analysis</li>
                <li>✓ Conflict Detection</li>
              </ul>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-lg p-4 border border-green-100">
              <h4 className="font-semibold text-green-800 mb-2">💾 Export & Integration</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                <li>✓ JSON Export</li>
                <li>✓ CSV Export</li>
                <li>✓ MS Project XML</li>
                <li>✓ Data Import/Export</li>
                <li>✓ Real-time Updates</li>
                <li>✓ Undo/Redo Support</li>
              </ul>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
