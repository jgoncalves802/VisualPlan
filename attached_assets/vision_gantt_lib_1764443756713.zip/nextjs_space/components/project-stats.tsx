
/**
 * ProjectStats - Display project statistics
 */

'use client';

import React from 'react';
import { Calendar, CheckCircle2, Clock, AlertCircle, Link2 } from 'lucide-react';
import type { ViewPreset } from '@/lib/vision-gantt/types';

interface ProjectStatsProps {
  stats: {
    totalTasks: number;
    completedTasks: number;
    inProgressTasks: number;
    notStartedTasks: number;
    totalDependencies: number;
  };
  viewPreset: ViewPreset;
}

export function ProjectStats({ stats, viewPreset }: ProjectStatsProps) {
  const completionPercentage = Math.round((stats.completedTasks / stats.totalTasks) * 100);

  const statCards = [
    {
      icon: Calendar,
      label: 'Total Tasks',
      value: stats.totalTasks,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      icon: CheckCircle2,
      label: 'Completed',
      value: stats.completedTasks,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      icon: Clock,
      label: 'In Progress',
      value: stats.inProgressTasks,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      icon: AlertCircle,
      label: 'Not Started',
      value: stats.notStartedTasks,
      color: 'text-gray-600',
      bgColor: 'bg-gray-50'
    },
    {
      icon: Link2,
      label: 'Dependencies',
      value: stats.totalDependencies,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div
            key={index}
            className="bg-white rounded-xl p-5 shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          </div>
        );
      })}
      
      {/* Completion Progress Card */}
      <div className="col-span-2 md:col-span-3 lg:col-span-5 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 shadow-lg text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold mb-1">Project Completion</h3>
            <p className="text-blue-100 text-sm">Overall progress across all tasks</p>
          </div>
          <div className="text-4xl font-bold">{completionPercentage}%</div>
        </div>
        <div className="w-full bg-blue-400 rounded-full h-3 overflow-hidden">
          <div
            className="bg-white h-full rounded-full transition-all duration-500"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
        <div className="mt-3 flex items-center justify-between text-sm text-blue-100">
          <span>{stats.completedTasks} of {stats.totalTasks} tasks completed</span>
          <span>View: {viewPreset.charAt(0).toUpperCase() + viewPreset.slice(1)}</span>
        </div>
      </div>
    </div>
  );
}
