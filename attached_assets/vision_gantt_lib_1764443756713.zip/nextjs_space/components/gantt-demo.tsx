
/**
 * GanttDemo - Main demo component
 */

'use client';

import React, { useState, useCallback } from 'react';
import { GanttChart } from '@/lib/vision-gantt';
import type { Task, Dependency, ViewPreset } from '@/lib/vision-gantt/types';
import { mockTasks, mockDependencies, projectStats } from '@/lib/data/mock-data';
import { ProjectStats } from './project-stats';
import { TaskDetailsPanel } from './task-details-panel';

export function GanttDemo() {
  const [tasks, setTasks] = useState(mockTasks);
  const [dependencies, setDependencies] = useState(mockDependencies);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [viewPreset, setViewPreset] = useState<ViewPreset>('month');

  const handleTaskUpdate = useCallback((task: Task) => {
    console.log('Task updated:', task);
    // In a real app, you would update your backend here
  }, []);

  const handleTaskClick = useCallback((task: Task) => {
    setSelectedTask(task);
  }, []);

  const handleDependencyCreate = useCallback((dependency: Dependency) => {
    console.log('Dependency created:', dependency);
    // In a real app, you would update your backend here
  }, []);

  const handleViewPresetChange = useCallback((preset: ViewPreset) => {
    setViewPreset(preset);
  }, []);

  return (
    <div className="space-y-6">
      {/* Project Statistics */}
      <ProjectStats stats={projectStats} viewPreset={viewPreset} />

      {/* Main Gantt Chart */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
        <GanttChart
          tasks={tasks}
          dependencies={dependencies}
          viewPreset={viewPreset}
          height={700}
          gridWidth={400}
          enableDragDrop={true}
          enableResize={true}
          enableDependencyCreation={false}
          onTaskUpdate={handleTaskUpdate}
          onTaskClick={handleTaskClick}
          onDependencyCreate={handleDependencyCreate}
          onViewPresetChange={handleViewPresetChange}
        />
      </div>

      {/* Task Details Panel */}
      {selectedTask && (
        <TaskDetailsPanel
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
        />
      )}

      {/* Instructions */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-3">
          💡 How to Use
        </h3>
        <ul className="space-y-2 text-sm text-blue-700">
          <li className="flex items-start gap-2">
            <span className="font-semibold min-w-[120px]">Drag Tasks:</span>
            <span>Click and drag task bars to adjust start/end dates</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-semibold min-w-[120px]">Resize Tasks:</span>
            <span>Hover over task edges and drag to adjust duration</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-semibold min-w-[120px]">Expand/Collapse:</span>
            <span>Click the arrow icons to show/hide child tasks</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-semibold min-w-[120px]">Zoom:</span>
            <span>Use the zoom controls at the top to change the timeline view</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-semibold min-w-[120px]">Dependencies:</span>
            <span>Hover over dependency lines to see connection types (FS, SS, FF, SF)</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
