
/**
 * ResourceManagementDemo - Complete resource management demonstration
 * Integrates all resource features: allocation, histogram, cost tracking
 */

'use client';

import React, { useState, useMemo } from 'react';
import { GanttChart } from '@/lib/vision-gantt';
import { ResourceHistogram } from '@/lib/vision-gantt/components/resource-histogram';
import { ResourceCostSummary } from '@/lib/vision-gantt/components/resource-cost-summary';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { mockTasks, mockDependencies } from '@/lib/data/mock-data';
import { mockResources, mockAllocations } from '@/lib/data/mock-advanced-data';
import { ResourceStore } from '@/lib/vision-gantt/stores/resource-store';
import type { Task, Resource } from '@/lib/vision-gantt/types';
import type { ResourceAllocation } from '@/lib/vision-gantt/types/advanced-features';
import { 
  Users, 
  DollarSign, 
  AlertTriangle, 
  BarChart3, 
  TrendingUp,
  Filter,
  RefreshCw
} from 'lucide-react';

interface ResourceAssignment {
  resourceId: string;
  resourceName: string;
  units: number;
}

// Deterministic number formatter to prevent hydration errors
function formatCurrency(value: number): string {
  const formatted = Math.round(value).toString();
  const parts = [];
  for (let i = formatted.length; i > 0; i -= 3) {
    parts.unshift(formatted.slice(Math.max(0, i - 3), i));
  }
  return parts.join(',');
}

export function ResourceManagementDemo() {
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [selectedTaskId, setSelectedTaskId] = useState<string | undefined>();
  const [selectedResourceId, setSelectedResourceId] = useState<string | undefined>();
  const [histogramGroupBy, setHistogramGroupBy] = useState<'day' | 'week' | 'month'>('week');
  
  // Initialize ResourceStore
  const resourceStore = useMemo(() => {
    return new ResourceStore(mockResources, mockAllocations, []);
  }, []);

  // Get current allocations and conflicts
  const [allocations, setAllocations] = useState<ResourceAllocation[]>(mockAllocations);
  const [resources] = useState<Resource[]>(mockResources);
  const conflicts = resourceStore.getConflicts();
  const stats = resourceStore.getStats();

  // Calculate date range from tasks
  const dateRange = useMemo(() => {
    if (tasks.length === 0) {
      return {
        startDate: new Date(),
        endDate: new Date()
      };
    }

    return {
      startDate: new Date(Math.min(...tasks.map(t => t.startDate.getTime()))),
      endDate: new Date(Math.max(...tasks.map(t => t.endDate.getTime())))
    };
  }, [tasks]);

  // Handle resource allocation update
  const handleResourceUpdate = (taskId: string, assignments: ResourceAssignment[]) => {
    console.log('Resource update:', { taskId, assignments });

    // Update allocations
    const updatedAllocations = allocations.filter(a => a.taskId !== taskId);
    
    assignments.forEach(assignment => {
      const task = tasks.find(t => t.id === taskId);
      if (!task) return;

      const newAllocation: ResourceAllocation = {
        id: `alloc-${taskId}-${assignment.resourceId}`,
        resourceId: assignment.resourceId,
        taskId,
        units: assignment.units * (task.duration || 8) / 100, // Convert % to hours
        type: 'hours',
        startDate: task.startDate,
        endDate: task.endDate
      };

      updatedAllocations.push(newAllocation);
    });

    setAllocations(updatedAllocations);

    // Update resource store
    updatedAllocations.forEach(alloc => {
      const existing = resourceStore.getAllocations().find(a => a.id === alloc.id);
      if (existing) {
        resourceStore.updateAllocation(alloc.id, alloc);
      } else {
        resourceStore.addAllocation(alloc);
      }
    });
  };

  // Calculate summary statistics
  const summaryStats = useMemo(() => {
    const totalCost = resources.reduce((sum, r) => {
      const resourceAllocations = allocations.filter(a => a.resourceId === r.id);
      let cost = 0;
      resourceAllocations.forEach(alloc => {
        const hours = (alloc.endDate.getTime() - alloc.startDate.getTime()) / (1000 * 60 * 60);
        cost += hours * (r.costRate || 0);
      });
      return sum + cost;
    }, 0);

    const totalAllocations = allocations.length;
    const overallocatedResources = new Set(conflicts.map(c => c.resourceId)).size;
    const avgUtilization = resources.length > 0
      ? Math.round((allocations.length / (resources.length * 5)) * 100) // Rough estimate
      : 0;

    return {
      totalCost: Math.round(totalCost),
      totalAllocations,
      overallocatedResources,
      avgUtilization
    };
  }, [resources, allocations, conflicts]);

  // Handle refresh
  const handleRefresh = () => {
    setAllocations([...mockAllocations]);
    setSelectedResourceId(undefined);
    setHistogramGroupBy('week');
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Resource Management
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Comprehensive resource allocation, workload analysis, and cost tracking
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            className="gap-2"
          >
            <RefreshCw size={16} />
            Reset
          </Button>
        </div>

        {/* Summary Statistics */}
        <div className="grid grid-cols-4 gap-4">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 mb-1">Total Resources</p>
                <p className="text-2xl font-bold text-blue-600">{stats.totalResources}</p>
              </div>
              <Users size={24} className="text-blue-500" />
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 mb-1">Total Cost</p>
                <p className="text-2xl font-bold text-green-600">
                  ${formatCurrency(summaryStats.totalCost)}
                </p>
              </div>
              <DollarSign size={24} className="text-green-500" />
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 mb-1">Conflicts</p>
                <p className="text-2xl font-bold text-orange-600">{stats.totalConflicts}</p>
              </div>
              <AlertTriangle size={24} className="text-orange-500" />
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 mb-1">Avg Utilization</p>
                <p className="text-2xl font-bold text-purple-600">
                  {summaryStats.avgUtilization}%
                </p>
              </div>
              <TrendingUp size={24} className="text-purple-500" />
            </div>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Side - Gantt Chart */}
        <div className="flex-1 bg-white border-r border-gray-200 overflow-hidden">
          <div className="h-full flex flex-col">
            <div className="px-6 py-3 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">
                Project Timeline with Resources
              </h2>
              <p className="text-xs text-gray-500 mt-1">
                Click on the Resources column to allocate resources to tasks
              </p>
            </div>
            <div className="flex-1 overflow-hidden">
              <GanttChart
                tasks={tasks}
                dependencies={mockDependencies}
                onTaskUpdate={(updatedTask) => {
                  setTasks(prev => 
                    prev.map(t => t.id === updatedTask.id ? updatedTask : t)
                  );
                }}
                onTaskClick={(task) => setSelectedTaskId(task.id)}
                resources={resources}
              />
            </div>
          </div>
        </div>

        {/* Right Side - Resource Analysis */}
        <div className="w-[500px] bg-white overflow-y-auto">
          <Tabs defaultValue="histogram" className="h-full">
            <div className="sticky top-0 bg-white border-b border-gray-200 z-10">
              <TabsList className="w-full grid grid-cols-2 rounded-none">
                <TabsTrigger value="histogram" className="gap-2">
                  <BarChart3 size={16} />
                  Workload
                </TabsTrigger>
                <TabsTrigger value="costs" className="gap-2">
                  <DollarSign size={16} />
                  Costs
                </TabsTrigger>
              </TabsList>
            </div>

            {/* Histogram Tab */}
            <TabsContent value="histogram" className="p-4 space-y-4">
              {/* Filters */}
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Filter size={16} className="text-gray-500" />
                  <h3 className="text-sm font-semibold">Filters</h3>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block">
                      Resource
                    </label>
                    <Select
                      value={selectedResourceId || 'all'}
                      onValueChange={(value) => 
                        setSelectedResourceId(value === 'all' ? undefined : value)
                      }
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="All Resources" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Resources</SelectItem>
                        {resources.map((resource) => (
                          <SelectItem key={resource.id} value={resource.id}>
                            {resource.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 mb-1 block">
                      Group By
                    </label>
                    <Select
                      value={histogramGroupBy}
                      onValueChange={(value: any) => setHistogramGroupBy(value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="day">Day</SelectItem>
                        <SelectItem value="week">Week</SelectItem>
                        <SelectItem value="month">Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </Card>

              {/* Histogram */}
              <ResourceHistogram
                resources={resources}
                allocations={allocations}
                startDate={dateRange.startDate}
                endDate={dateRange.endDate}
                selectedResourceId={selectedResourceId}
                groupBy={histogramGroupBy}
              />

              {/* Conflicts Alert */}
              {conflicts.length > 0 && (
                <Card className="p-4 bg-orange-50 border-orange-200">
                  <div className="flex items-start gap-3">
                    <AlertTriangle size={20} className="text-orange-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-orange-900 mb-1">
                        Resource Conflicts Detected
                      </h4>
                      <p className="text-xs text-orange-700 mb-2">
                        {conflicts.length} conflict{conflicts.length > 1 ? 's' : ''} found. 
                        Resources are overallocated during specific periods.
                      </p>
                      <div className="space-y-1">
                        {conflicts.slice(0, 3).map((conflict, idx) => {
                          const resource = resources.find(r => r.id === conflict.resourceId);
                          return (
                            <div key={idx} className="text-xs text-orange-800">
                              • {resource?.name || 'Unknown'}: {conflict.allocatedUnits}h 
                              (capacity: {conflict.availableUnits}h)
                            </div>
                          );
                        })}
                        {conflicts.length > 3 && (
                          <div className="text-xs text-orange-700 italic">
                            +{conflicts.length - 3} more conflict{conflicts.length - 3 > 1 ? 's' : ''}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              )}
            </TabsContent>

            {/* Costs Tab */}
            <TabsContent value="costs" className="p-4">
              <ResourceCostSummary
                resources={resources}
                allocations={allocations}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
