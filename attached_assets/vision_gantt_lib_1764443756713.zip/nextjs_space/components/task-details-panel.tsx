
/**
 * TaskDetailsPanel - Display detailed task information
 */

'use client';

import React from 'react';
import { X, Calendar, Clock, TrendingUp, Tag } from 'lucide-react';
import type { Task } from '@/lib/vision-gantt/types';
import { format } from 'date-fns';

interface TaskDetailsPanelProps {
  task: Task;
  onClose: () => void;
}

export function TaskDetailsPanel({ task, onClose }: TaskDetailsPanelProps) {
  const statusColors = {
    completed: 'bg-green-100 text-green-800',
    in_progress: 'bg-blue-100 text-blue-800',
    not_started: 'bg-gray-100 text-gray-800',
    on_hold: 'bg-red-100 text-red-800'
  };

  const statusLabels = {
    completed: 'Completed',
    in_progress: 'In Progress',
    not_started: 'Not Started',
    on_hold: 'On Hold'
  };

  return (
    <div className="fixed bottom-6 right-6 w-96 bg-white rounded-xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 text-white">
        <div className="flex items-start justify-between">
          <div className="flex-1 pr-4">
            <h3 className="font-semibold text-lg mb-1">{task?.name ?? 'Task Details'}</h3>
            {task?.wbs && (
              <p className="text-blue-100 text-sm">WBS: {task.wbs}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/20 rounded-lg transition-colors"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4 max-h-96 overflow-y-auto">
        {/* Status */}
        <div className="flex items-center gap-2">
          <Tag size={16} className="text-gray-500" />
          <span className="text-sm text-gray-600">Status:</span>
          <span
            className={`px-2 py-1 rounded-full text-xs font-medium ${
              statusColors[task?.status ?? 'not_started']
            }`}
          >
            {statusLabels[task?.status ?? 'not_started']}
          </span>
        </div>

        {/* Dates */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Calendar size={16} className="text-gray-500" />
            <span className="text-sm text-gray-600">Start Date:</span>
            <span className="text-sm font-medium text-gray-800">
              {task?.startDate ? format(new Date(task.startDate), 'MMM d, yyyy') : '-'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar size={16} className="text-gray-500" />
            <span className="text-sm text-gray-600">End Date:</span>
            <span className="text-sm font-medium text-gray-800">
              {task?.endDate ? format(new Date(task.endDate), 'MMM d, yyyy') : '-'}
            </span>
          </div>
        </div>

        {/* Duration */}
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-gray-500" />
          <span className="text-sm text-gray-600">Duration:</span>
          <span className="text-sm font-medium text-gray-800">
            {task?.duration ?? 0} days
          </span>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <TrendingUp size={16} className="text-gray-500" />
            <span className="text-sm text-gray-600">Progress:</span>
            <span className="text-sm font-medium text-gray-800">
              {task?.progress ?? 0}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <div
              className="bg-blue-600 h-full rounded-full transition-all"
              style={{ width: `${task?.progress ?? 0}%` }}
            />
          </div>
        </div>

        {/* Milestone */}
        {task?.isMilestone && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <p className="text-sm text-amber-800 font-medium">
              🏆 This is a milestone task
            </p>
          </div>
        )}

        {/* Description */}
        {task?.description && (
          <div className="pt-3 border-t border-gray-200">
            <p className="text-sm text-gray-600 mb-1 font-medium">Description:</p>
            <p className="text-sm text-gray-700">{task.description}</p>
          </div>
        )}
      </div>
    </div>
  );
}
