# 📘 Guia de Uso - VisionGantt Library

## 🎯 Visão Geral

A **VisionGantt** é uma biblioteca React completa para gráficos de Gantt com recursos avançados de gerenciamento de projetos, similar ao Microsoft Project e Primavera P6.

---

## 📦 Instalação

### 1. Copiar a Biblioteca para seu Projeto

Copie a pasta `lib/vision-gantt` para o diretório `lib` do seu projeto Next.js:

```bash
cp -r /home/ubuntu/vision_gantt_lib/nextjs_space/lib/vision-gantt /seu-projeto/lib/
```

### 2. Instalar Dependências

A biblioteca requer as seguintes dependências:

```bash
yarn add date-fns zustand jotai
yarn add -D @types/node
```

### 3. Configurar Tailwind CSS

Adicione o caminho da biblioteca no `tailwind.config.ts`:

```typescript
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/vision-gantt/**/*.{js,ts,jsx,tsx}', // Adicione esta linha
  ],
  // ... resto da configuração
}
```

### 4. Copiar Estilos Globais

Copie os estilos necessários para `app/globals.css`:

```css
/* Dependency Handle Styles */
.gantt-task-hover-area:hover .dependency-handle {
  opacity: 1;
  pointer-events: all;
}

.dependency-handle {
  transition: opacity 0.2s ease-in-out;
}

.gantt-task-bar:hover .dependency-handle {
  opacity: 1;
}
```

---

## 🚀 Uso Básico

### Exemplo Simples

```tsx
'use client';

import { GanttChart } from '@/lib/vision-gantt';
import { useState } from 'react';
import type { Task, Dependency } from '@/lib/vision-gantt/types';

export default function MeuGantt() {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      name: 'Planejamento',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-15'),
      progress: 100,
      status: 'completed',
      wbs: '1',
      level: 0,
    },
    {
      id: '2',
      name: 'Desenvolvimento',
      startDate: new Date('2025-01-16'),
      endDate: new Date('2025-02-28'),
      progress: 60,
      status: 'in-progress',
      wbs: '2',
      level: 0,
    },
  ]);

  const [dependencies] = useState<Dependency[]>([
    {
      id: 'dep-1',
      fromTaskId: '1',
      toTaskId: '2',
      type: 'FS', // Finish-to-Start
    },
  ]);

  return (
    <div className="h-screen p-4">
      <GanttChart
        tasks={tasks}
        dependencies={dependencies}
        onTaskUpdate={(updatedTask) => {
          setTasks(prev => 
            prev.map(t => t.id === updatedTask.id ? updatedTask : t)
          );
        }}
      />
    </div>
  );
}
```

---

## ⚙️ Propriedades do GanttChart

### Propriedades Principais

| Propriedade | Tipo | Obrigatório | Descrição |
|------------|------|-------------|----------|
| `tasks` | `Task[]` | ✅ | Array de tarefas |
| `dependencies` | `Dependency[]` | ✅ | Array de dependências |
| `onTaskUpdate` | `(task: Task) => void` | ❌ | Callback ao atualizar tarefa |
| `onTaskClick` | `(task: Task) => void` | ❌ | Callback ao clicar em tarefa |
| `resources` | `Resource[]` | ❌ | Array de recursos |
| `viewPreset` | `'hour' \| 'day' \| 'week' \| 'month'` | ❌ | Escala de tempo (padrão: 'month') |
| `enableDragDrop` | `boolean` | ❌ | Habilitar arrastar tarefas (padrão: true) |
| `enableResize` | `boolean` | ❌ | Habilitar redimensionar tarefas (padrão: true) |
| `enableDependencyCreation` | `boolean` | ❌ | Habilitar criar dependências (padrão: true) |

---

## 📊 Estrutura de Dados

### Task (Tarefa)

```typescript
interface Task {
  id: string;                    // ID único
  name: string;                  // Nome da tarefa
  startDate: Date;               // Data de início
  endDate: Date;                 // Data de término
  progress: number;              // Progresso (0-100)
  status: 'not-started' | 'in-progress' | 'completed';
  wbs?: string;                  // Work Breakdown Structure
  level?: number;                // Nível de hierarquia (0 = raiz)
  parentId?: string;             // ID da tarefa pai
  duration?: number;             // Duração em dias
  color?: string;                // Cor customizada
  isExpanded?: boolean;          // Se está expandida (para tarefas pai)
}
```

### Dependency (Dependência)

```typescript
interface Dependency {
  id: string;
  fromTaskId: string;            // ID da tarefa origem
  toTaskId: string;              // ID da tarefa destino
  type: 'FS' | 'SS' | 'FF' | 'SF'; // Tipo de dependência
  lag?: number;                  // Atraso em dias (opcional)
}
```

**Tipos de Dependência:**
- `FS` (Finish-to-Start): Tarefa B inicia quando A termina
- `SS` (Start-to-Start): Ambas iniciam juntas
- `FF` (Finish-to-Finish): Ambas terminam juntas
- `SF` (Start-to-Finish): B termina quando A inicia

---

## 🎨 Recursos Avançados

### 1. Gerenciamento de Recursos

```tsx
import { GanttChart } from '@/lib/vision-gantt';
import type { Resource, ResourceAllocation } from '@/lib/vision-gantt/types/advanced-features';

const resources: Resource[] = [
  {
    id: 'res-1',
    name: 'João Silva',
    role: 'Desenvolvedor',
    capacity: 8, // horas por dia
    costRate: 100, // custo por hora
    costType: 'hourly',
  },
];

const allocations: ResourceAllocation[] = [
  {
    id: 'alloc-1',
    resourceId: 'res-1',
    taskId: 'task-1',
    units: 8, // horas alocadas
    type: 'hours',
    startDate: new Date('2025-01-01'),
    endDate: new Date('2025-01-15'),
  },
];

<GanttChart
  tasks={tasks}
  dependencies={dependencies}
  resources={resources}
/>
```

### 2. Histograma de Recursos

```tsx
import { ResourceHistogram } from '@/lib/vision-gantt/components/resource-histogram';

<ResourceHistogram
  resources={resources}
  allocations={allocations}
  startDate={new Date('2025-01-01')}
  endDate={new Date('2025-12-31')}
  groupBy="week" // 'day' | 'week' | 'month'
/>
```

### 3. Resumo de Custos

```tsx
import { ResourceCostSummary } from '@/lib/vision-gantt/components/resource-cost-summary';

<ResourceCostSummary
  resources={resources}
  allocations={allocations}
/>
```

---

## 🔧 Customização

### Colunas Personalizadas

```tsx
import type { ColumnConfig } from '@/lib/vision-gantt/types';

const customColumns: ColumnConfig[] = [
  {
    id: 'wbs',
    label: 'WBS',
    width: 60,
    minWidth: 50,
    maxWidth: 100,
    renderer: (task) => task.wbs || '-',
  },
  {
    id: 'name',
    label: 'Task Name',
    width: 300,
    minWidth: 200,
    maxWidth: 500,
    renderer: (task) => task.name,
  },
  {
    id: 'custom',
    label: 'Responsável',
    width: 150,
    renderer: (task) => task.assignee || 'Não atribuído',
  },
];

<GanttChart
  tasks={tasks}
  dependencies={dependencies}
  columns={customColumns}
/>
```

### Cores Personalizadas

```tsx
const tasks: Task[] = [
  {
    id: '1',
    name: 'Tarefa Crítica',
    startDate: new Date('2025-01-01'),
    endDate: new Date('2025-01-15'),
    progress: 50,
    status: 'in-progress',
    color: '#ef4444', // Vermelho para tarefas críticas
  },
];
```

---

## 📱 Componentes Prontos

### Demo Completo com Recursos

```tsx
import { ResourceManagementDemo } from '@/components/resource-management-demo';

export default function Page() {
  return <ResourceManagementDemo />;
}
```

Este componente inclui:
- ✅ Gráfico de Gantt interativo
- ✅ Painel de estatísticas
- ✅ Histograma de recursos
- ✅ Resumo de custos
- ✅ Detecção de conflitos

---

## 🎯 Exemplos de Uso

### 1. Projeto de Desenvolvimento de Software

```tsx
const softwareProject: Task[] = [
  {
    id: '1',
    name: 'PLANEJAMENTO',
    startDate: new Date('2025-01-01'),
    endDate: new Date('2025-01-31'),
    progress: 100,
    status: 'completed',
    wbs: '1',
    level: 0,
  },
  {
    id: '1.1',
    name: 'Levantamento de Requisitos',
    startDate: new Date('2025-01-01'),
    endDate: new Date('2025-01-15'),
    progress: 100,
    status: 'completed',
    wbs: '1.1',
    level: 1,
    parentId: '1',
  },
  {
    id: '2',
    name: 'DESENVOLVIMENTO',
    startDate: new Date('2025-02-01'),
    endDate: new Date('2025-03-31'),
    progress: 40,
    status: 'in-progress',
    wbs: '2',
    level: 0,
  },
];
```

### 2. Projeto de Construção

```tsx
const constructionProject: Task[] = [
  {
    id: '1',
    name: 'Fundação',
    startDate: new Date('2025-01-01'),
    endDate: new Date('2025-01-30'),
    progress: 100,
    status: 'completed',
    wbs: '1',
    color: '#8b5cf6',
  },
  {
    id: '2',
    name: 'Estrutura',
    startDate: new Date('2025-02-01'),
    endDate: new Date('2025-03-15'),
    progress: 60,
    status: 'in-progress',
    wbs: '2',
    color: '#3b82f6',
  },
];
```

---

## 🐛 Solução de Problemas

### Erro de Hidratação

Se você encontrar erros de hidratação com datas ou números, use as funções utilitárias:

```tsx
import { formatDate, formatCurrency } from '@/lib/vision-gantt/utils/format-utils';

// ✅ Correto
const dateText = formatDate(new Date());
const costText = formatCurrency(1234.56);

// ❌ Evite
const dateText = new Date().toLocaleDateString();
const costText = value.toLocaleString();
```

### Performance com Muitas Tarefas

Para projetos com mais de 500 tarefas:

1. Use `React.memo` nos componentes customizados
2. Implemente virtualização de lista
3. Limite o número de dependências visíveis

---

## 📚 Recursos Adicionais

### Documentação Técnica
- `USAGE_GUIDE.md` - Guia de uso em inglês
- `ADVANCED_FEATURES.md` - Recursos avançados
- `FULL_FEATURES.md` - Documentação completa

### Exemplos de Código
- `components/full-features-demo.tsx` - Demo completo
- `components/resource-management-demo.tsx` - Gestão de recursos
- `lib/data/mock-data.ts` - Dados de exemplo

---

## 🤝 Suporte

Para dúvidas ou problemas:
1. Consulte os arquivos de documentação no diretório raiz
2. Verifique os exemplos em `components/`
3. Analise os tipos em `lib/vision-gantt/types/`

---

## 📝 Licença

Esta biblioteca é fornecida como está para uso em seus projetos.

---

**Versão:** 1.0.0  
**Última Atualização:** Novembro 2025
