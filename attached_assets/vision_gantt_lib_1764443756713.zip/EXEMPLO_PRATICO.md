# 🚀 Exemplo Prático - VisionGantt

## Exemplo Completo - Passo a Passo

### 1️⃣ Criar Componente Básico

Crie o arquivo `app/meu-gantt/page.tsx`:

```tsx
'use client';

import { GanttChart } from '@/lib/vision-gantt';
import { useState } from 'react';
import type { Task, Dependency } from '@/lib/vision-gantt/types';

export default function MeuProjetoGantt() {
  // Dados das tarefas
  const [tasks, setTasks] = useState<Task[]>([
    // FASE 1: PLANEJAMENTO
    {
      id: '1',
      name: 'PLANEJAMENTO',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-31'),
      progress: 100,
      status: 'completed',
      wbs: '1',
      level: 0,
      isExpanded: true,
    },
    {
      id: '1.1',
      name: 'Reunião de Kickoff',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-03'),
      progress: 100,
      status: 'completed',
      wbs: '1.1',
      level: 1,
      parentId: '1',
    },
    {
      id: '1.2',
      name: 'Levantamento de Requisitos',
      startDate: new Date('2025-01-04'),
      endDate: new Date('2025-01-20'),
      progress: 100,
      status: 'completed',
      wbs: '1.2',
      level: 1,
      parentId: '1',
    },
    
    // FASE 2: DESENVOLVIMENTO
    {
      id: '2',
      name: 'DESENVOLVIMENTO',
      startDate: new Date('2025-02-01'),
      endDate: new Date('2025-03-31'),
      progress: 45,
      status: 'in-progress',
      wbs: '2',
      level: 0,
      isExpanded: true,
    },
    {
      id: '2.1',
      name: 'Backend API',
      startDate: new Date('2025-02-01'),
      endDate: new Date('2025-02-28'),
      progress: 70,
      status: 'in-progress',
      wbs: '2.1',
      level: 1,
      parentId: '2',
    },
    {
      id: '2.2',
      name: 'Frontend UI',
      startDate: new Date('2025-02-15'),
      endDate: new Date('2025-03-20'),
      progress: 30,
      status: 'in-progress',
      wbs: '2.2',
      level: 1,
      parentId: '2',
    },
    
    // FASE 3: TESTES
    {
      id: '3',
      name: 'TESTES',
      startDate: new Date('2025-04-01'),
      endDate: new Date('2025-04-30'),
      progress: 0,
      status: 'not-started',
      wbs: '3',
      level: 0,
      isExpanded: true,
    },
    {
      id: '3.1',
      name: 'Testes Unitários',
      startDate: new Date('2025-04-01'),
      endDate: new Date('2025-04-15'),
      progress: 0,
      status: 'not-started',
      wbs: '3.1',
      level: 1,
      parentId: '3',
    },
  ]);

  // Dependências entre tarefas
  const [dependencies] = useState<Dependency[]>([
    {
      id: 'dep-1',
      fromTaskId: '1.1',
      toTaskId: '1.2',
      type: 'FS', // Finish-to-Start
    },
    {
      id: 'dep-2',
      fromTaskId: '1',
      toTaskId: '2',
      type: 'FS',
    },
    {
      id: 'dep-3',
      fromTaskId: '2.1',
      toTaskId: '2.2',
      type: 'SS', // Start-to-Start
    },
    {
      id: 'dep-4',
      fromTaskId: '2',
      toTaskId: '3',
      type: 'FS',
    },
  ]);

  // Handler para atualizar tarefas quando são arrastadas/redimensionadas
  const handleTaskUpdate = (updatedTask: Task) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === updatedTask.id ? updatedTask : task
      )
    );
    console.log('Tarefa atualizada:', updatedTask);
  };

  // Handler para cliques em tarefas
  const handleTaskClick = (task: Task) => {
    console.log('Tarefa clicada:', task);
    alert(`Você clicou na tarefa: ${task.name}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-[1800px] mx-auto">
        {/* Cabeçalho */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Meu Projeto - Cronograma
          </h1>
          <p className="text-gray-600">
            Gerencie seu projeto com gráfico de Gantt interativo
          </p>
        </div>

        {/* Gráfico de Gantt */}
        <div className="bg-white rounded-lg shadow-lg p-4">
          <GanttChart
            tasks={tasks}
            dependencies={dependencies}
            onTaskUpdate={handleTaskUpdate}
            onTaskClick={handleTaskClick}
            viewPreset="month"
            enableDragDrop={true}
            enableResize={true}
            enableDependencyCreation={true}
            height={600}
          />
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm text-gray-600 mb-1">Total de Tarefas</h3>
            <p className="text-2xl font-bold text-blue-600">{tasks.length}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm text-gray-600 mb-1">Concluídas</h3>
            <p className="text-2xl font-bold text-green-600">
              {tasks.filter(t => t.status === 'completed').length}
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm text-gray-600 mb-1">Em Progresso</h3>
            <p className="text-2xl font-bold text-orange-600">
              {tasks.filter(t => t.status === 'in-progress').length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
```

---

### 2️⃣ Exemplo com Recursos

Crie o arquivo `app/projeto-com-recursos/page.tsx`:

```tsx
'use client';

import { GanttChart } from '@/lib/vision-gantt';
import { ResourceHistogram } from '@/lib/vision-gantt/components/resource-histogram';
import { useState } from 'react';
import type { Task, Dependency, Resource } from '@/lib/vision-gantt/types';
import type { ResourceAllocation } from '@/lib/vision-gantt/types/advanced-features';

export default function ProjetoComRecursos() {
  // Tarefas
  const [tasks] = useState<Task[]>([
    {
      id: '1',
      name: 'Desenvolvimento Frontend',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-31'),
      progress: 50,
      status: 'in-progress',
      wbs: '1',
      level: 0,
    },
    {
      id: '2',
      name: 'Desenvolvimento Backend',
      startDate: new Date('2025-01-15'),
      endDate: new Date('2025-02-15'),
      progress: 30,
      status: 'in-progress',
      wbs: '2',
      level: 0,
    },
  ]);

  // Recursos (pessoas/equipes)
  const resources: Resource[] = [
    {
      id: 'res-1',
      name: 'João Silva',
      role: 'Desenvolvedor Frontend',
      capacity: 8, // 8 horas por dia
      costRate: 100, // R$100/hora
      costType: 'hourly',
    },
    {
      id: 'res-2',
      name: 'Maria Santos',
      role: 'Desenvolvedora Backend',
      capacity: 8,
      costRate: 120,
      costType: 'hourly',
    },
  ];

  // Alocações de recursos
  const allocations: ResourceAllocation[] = [
    {
      id: 'alloc-1',
      resourceId: 'res-1',
      taskId: '1',
      units: 8, // 8 horas por dia
      type: 'hours',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-31'),
    },
    {
      id: 'alloc-2',
      resourceId: 'res-2',
      taskId: '2',
      units: 8,
      type: 'hours',
      startDate: new Date('2025-01-15'),
      endDate: new Date('2025-02-15'),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-[1800px] mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Projeto com Gestão de Recursos</h1>
        
        {/* Gráfico de Gantt */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-xl font-semibold mb-4">Cronograma</h2>
          <GanttChart
            tasks={tasks}
            dependencies={[]}
            resources={resources}
            height={400}
          />
        </div>

        {/* Histograma de Recursos */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-xl font-semibold mb-4">Carga de Trabalho</h2>
          <ResourceHistogram
            resources={resources}
            allocations={allocations}
            startDate={new Date('2025-01-01')}
            endDate={new Date('2025-02-28')}
            groupBy="week"
          />
        </div>

        {/* Resumo de Custos */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-xl font-semibold mb-4">Resumo de Custos</h2>
          <div className="grid grid-cols-2 gap-4">
            {resources.map(resource => {
              const resourceAllocs = allocations.filter(
                a => a.resourceId === resource.id
              );
              const totalHours = resourceAllocs.reduce(
                (sum, alloc) => sum + alloc.units, 0
              );
              const totalCost = totalHours * resource.costRate;
              
              return (
                <div key={resource.id} className="border rounded p-4">
                  <h3 className="font-bold">{resource.name}</h3>
                  <p className="text-sm text-gray-600">{resource.role}</p>
                  <div className="mt-2 space-y-1">
                    <p className="text-sm">
                      <span className="text-gray-600">Horas:</span>{' '}
                      <span className="font-semibold">{totalHours}h</span>
                    </p>
                    <p className="text-sm">
                      <span className="text-gray-600">Custo:</span>{' '}
                      <span className="font-semibold text-green-600">
                        R$ {totalCost.toFixed(2)}
                      </span>
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
```

---

### 3️⃣ Exemplo Simples - Copiar e Colar

Exemplo mínimo para começar rápido:

```tsx
'use client';

import { GanttChart } from '@/lib/vision-gantt';

export default function GanttSimples() {
  const tarefas = [
    {
      id: '1',
      name: 'Tarefa 1',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-10'),
      progress: 100,
      status: 'completed' as const,
      wbs: '1',
      level: 0,
    },
    {
      id: '2',
      name: 'Tarefa 2',
      startDate: new Date('2025-01-11'),
      endDate: new Date('2025-01-20'),
      progress: 50,
      status: 'in-progress' as const,
      wbs: '2',
      level: 0,
    },
  ];

  return (
    <div className="p-4 h-screen">
      <GanttChart
        tasks={tarefas}
        dependencies={[]}
      />
    </div>
  );
}
```

---

### 4️⃣ Exemplo com Drag & Drop

```tsx
'use client';

import { GanttChart } from '@/lib/vision-gantt';
import { useState } from 'react';
import type { Task } from '@/lib/vision-gantt/types';

export default function GanttArrastar() {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      name: 'Arraste-me!',
      startDate: new Date('2025-01-01'),
      endDate: new Date('2025-01-10'),
      progress: 50,
      status: 'in-progress',
      wbs: '1',
      level: 0,
    },
  ]);

  return (
    <div className="p-4 h-screen">
      <div className="mb-4">
        <h2 className="text-xl font-bold">Arraste as barras para alterar as datas!</h2>
        <p className="text-gray-600">Arraste as extremidades para redimensionar</p>
      </div>
      
      <GanttChart
        tasks={tasks}
        dependencies={[]}
        onTaskUpdate={(updated) => {
          setTasks(prev => prev.map(t => t.id === updated.id ? updated : t));
          alert(`Nova data: ${updated.startDate.toLocaleDateString()} - ${updated.endDate.toLocaleDateString()}`);
        }}
        enableDragDrop={true}
        enableResize={true}
      />
    </div>
  );
}
```

---

## 💡 Dicas Rápidas

1. **Use `'use client'`** no topo do arquivo (obrigatório no Next.js 14+)
2. **Altura mínima**: Configure `height={600}` ou use `className="h-screen"`
3. **Datas**: Sempre use `new Date()` para as datas
4. **Status**: Use `'completed' | 'in-progress' | 'not-started'`
5. **WBS**: Numeração hierárquica (1, 1.1, 1.2, 2, 2.1...)

---

## ✅ Checklist de Integração

- [ ] Copiar pasta `lib/vision-gantt` para seu projeto
- [ ] Instalar dependências: `yarn add date-fns zustand jotai`
- [ ] Configurar Tailwind CSS
- [ ] Copiar estilos para `globals.css`
- [ ] Criar componente com `'use client'`
- [ ] Testar com dados de exemplo
- [ ] Adicionar seus próprios dados

---

**Pronto para começar!** 🎉

Escolha um dos exemplos acima e adapte para seu projeto!
