
# 📊 Análise do Design System: VisionGantt vs Bryntum Gantt

**Data:** 19 de Novembro de 2025  
**Objetivo:** Extrair design system do Bryntum Gantt e melhorar VisionGantt baseado nas melhores práticas

---

## 🎨 Análise do Design System Bryntum

### 1. **Grid de Atividades (Lista Lateral)**

#### **Características Observadas no Bryntum:**
```
┌────────────────────────────────────────────────┐
│ NAME           │ % DONE │ RESOURCES │ EFFORT │
├────────────────┼────────┼───────────┼────────┤
│ ▶ Launch SaaS  │  33%   │ 👤 3      │ 295d   │
│  ├▶ Setup web  │  25%   │ 👤 2      │ 45d    │
│  │ ├ Install   │  100%  │ 👤👤      │ 10d    │
│  │ ├ Configure │  50%   │ 👤        │ 15d    │
│  │ └ Setup LB  │   0%   │ 👤👤👤    │ 20d    │
└────────────────┴────────┴───────────┴────────┘
```

**Características Chave:**
- ✅ **Colunas Redimensionáveis**: Arrastar divisores entre colunas
- ✅ **Hierarquia Visual Clara**: Indentação + ícones expand/collapse
- ✅ **Barras de Progresso Inline**: Na coluna % DONE
- ✅ **Avatares de Recursos**: Múltiplos avatares empilhados
- ✅ **Reordenação Drag & Drop**: Arrastar linhas para reordenar
- ✅ **Edição Inline**: Clique duplo edita célula
- ✅ **Tooltips Ricos**: Hover mostra informações completas

#### **Estado Atual no VisionGantt:**
- ❌ Colunas fixas sem redimensionamento
- ✅ Hierarquia visual (mas pode melhorar)
- ❌ Sem barras de progresso inline
- ❌ Sem avatares de recursos
- ⚠️ Reordenação limitada
- ❌ Sem edição inline
- ✅ Tooltips básicos

---

### 2. **Timeline (Área do Gantt)**

#### **Características Observadas no Bryntum:**
```
┌─────────────────────────────────────────────────────────┐
│ JANUARY 2019          │ FEBRUARY 2019        │ MARCH   │
│ W1  W2  W3  W4  W5    │ W5  W6  W7  W8  W9   │ W9  W10 │
│ 6 13 20 27  3  10 17  │ 3 10 17 24  3  10 17 │ 10 17 24│
├─────────────────────────────────────────────────────────┤
│ ██████████████████████████                   │ Phase 1   │
│    ██████████                                │ Setup     │
│    ██████                                    │ Install   │
│           ████████                           │ Configure │
│                  ██████████                  │ Load Bal  │
└─────────────────────────────────────────────────────────┘
```

**Características Chave:**
- ✅ **Cabeçalho Multi-Nível**: Mês > Semana > Dia (configurável)
- ✅ **Scroll Horizontal Suave**: Pan com mouse wheel
- ✅ **Zoom Dinâmico**: Scroll + Ctrl para zoom
- ✅ **Grid de Fundo**: Linhas verticais para cada unidade
- ✅ **Today Marker**: Linha vertical vermelha para hoje
- ✅ **Barras Coloridas por Status**: Verde, azul, vermelho
- ✅ **Milestone Icons**: Losangos para marcos
- ✅ **Dependências Visuais**: Linhas conectando tarefas
- ✅ **Baseline Ghost**: Barras transparentes mostrando baseline
- ✅ **Progress Fill**: Preenchimento dentro da barra (progresso)
- ✅ **Drag Handles**: Pontos nas extremidades para resize
- ✅ **Labels nas Barras**: Nome ou % dentro/fora da barra

#### **Estado Atual no VisionGantt:**
- ✅ Cabeçalho multi-nível (implementado recentemente!)
- ✅ Scroll horizontal
- ⚠️ Zoom funcional mas pode melhorar UX
- ✅ Grid de fundo
- ❌ Today marker fraco
- ⚠️ Cores por status (mas limitadas)
- ❌ Milestone icons simplificados
- ❌ Dependências não visualizadas
- ❌ Sem baseline
- ⚠️ Progress fill básico
- ❌ Sem drag handles visuais
- ⚠️ Labels nas barras (pode melhorar)

---

### 3. **Toolbar e Controles**

#### **Características Observadas no Bryntum:**
```
┌────────────────────────────────────────────────────────┐
│ [+] Add Task  [🔍] Filter  [📊] View  [⚙️] Settings   │
│ [Zoom: ▓▓▓▓░░] [Today] [Undo] [Redo] [Export]        │
└────────────────────────────────────────────────────────┘
```

**Características Chave:**
- ✅ **Slider de Zoom**: Barra interativa para ajustar escala
- ✅ **Botão "Today"**: Scroll rápido para data atual
- ✅ **Undo/Redo**: Histórico de mudanças
- ✅ **View Presets**: Dropdown (Hour, Day, Week, Month, Year)
- ✅ **Filters**: Múltiplos filtros combinados
- ✅ **Settings**: Modal de configurações avançadas

#### **Estado Atual no VisionGantt:**
- ❌ Zoom via botões (+/-), não slider
- ❌ Sem botão Today
- ❌ Sem undo/redo
- ✅ View presets (dropdown existente)
- ⚠️ Filtros básicos
- ❌ Sem modal de settings avançado

---

### 4. **Recursos (Resources)**

#### **Características Observadas no Bryntum:**
```
┌──────────────────────────┐
│ RESOURCES                │
├──────────────────────────┤
│ 👤 Celia       ─────     │
│    2 tasks     7 days    │
│                          │
│ 👤 Lee         ─────     │
│    1 task      3 days    │
│                          │
│ 👤 Madison     ─────     │
│    0 tasks     0 days    │
└──────────────────────────┘
```

**Recursos em Tarefas:**
```
Install Apache    [👤👤]    2 resources
Configure FW      [👤]      1 resource
```

**Características Chave:**
- ✅ **Painel de Recursos**: Lista sidebar mostrando:
  - Avatar + Nome
  - Número de tarefas atribuídas
  - Total de dias alocados
  - Indicador de carga (overload em vermelho)
- ✅ **Atribuição Visual**: Avatares nas tarefas
- ✅ **Drag & Drop**: Arrastar recurso para tarefa
- ✅ **Histograma de Carga**: Gráfico mostrando utilização
- ✅ **Multi-Assignment**: Múltiplos recursos por tarefa
- ✅ **Allocation %**: Percentual de dedicação (25%, 50%, 100%)

#### **Estado Atual no VisionGantt:**
- ✅ ResourcePanel criado (fase avançada)
- ⚠️ Sem avatares visuais
- ❌ Sem drag & drop de recursos
- ❌ Sem histograma de carga
- ⚠️ Multi-assignment implementado (store)
- ❌ Sem allocation % visual

---

### 5. **WBS e Agrupamento (PMBOK)**

#### **Requisitos PMBOK:**
```
1.0 Launch SaaS Product
  1.1 Planning & Design
    1.1.1 Requirements Gathering
    1.1.2 Architecture Design
    1.1.3 UI/UX Design
  1.2 Development
    1.2.1 Frontend Development
    1.2.2 Backend Development
    1.2.3 Database Setup
  1.3 Testing & QA
  1.4 Deployment
```

**Características Necessárias:**
- ✅ **Numeração Automática WBS**: 1.0, 1.1, 1.1.1
- ✅ **Hierarquia Ilimitada**: Subnível-infinito
- ✅ **Roll-up Automático**:
  - Datas: Início = min(children), Fim = max(children)
  - Duração: sum(children) ou span(start, end)
  - Custo: sum(children.cost)
  - Progresso: weighted average
- ✅ **Indicadores Visuais**:
  - Fases (bold, background diferente)
  - Pacotes de Trabalho (tasks normais)
  - Deliverables (milestone icon)
- ✅ **Exportação para MS Project**: Manter estrutura WBS

#### **Estado Atual no VisionGantt:**
- ✅ Hierarquia implementada (nivel_wbs no banco)
- ⚠️ WBS codes no banco mas não exibidos
- ❌ Roll-up não automático
- ⚠️ Indicadores visuais básicos
- ❌ Exportação MS Project não implementada

---

### 6. **Calendários (MS Project Style)**

#### **Funcionalidades dos Calendários:**
```
📅 Standard (5x8)
   Mon-Fri: 08:00-12:00, 13:00-17:00 (8h/day)
   Sat-Sun: Non-working
   
📅 Intensive (6x10)
   Mon-Sat: 07:00-12:00, 13:00-18:00 (10h/day)
   Sun: Non-working
   
📅 24x7 Operations
   All days: 00:00-24:00 (24h/day)
```

**Exceções (Feriados):**
```
🔴 2025-01-01 - New Year (Non-working)
🔴 2025-04-21 - Tiradentes (Non-working)
🟠 2025-12-24 - Christmas Eve (Half-day: 08:00-12:00)
```

**Características Chave:**
- ✅ **Múltiplos Calendários**: Projeto, tarefa, recurso
- ✅ **Working Days**: Configurar dias úteis por semana
- ✅ **Working Hours**: Múltiplos períodos por dia
- ✅ **Exceções**: Feriados, dias especiais
- ✅ **Cálculo Automático**: Duração considera calendário
- ✅ **Calendário Default**: Um calendário padrão para projeto

#### **Estado Atual no VisionGantt:**
- ✅ CalendarStore implementado (stores/calendar-store.ts)
- ✅ CalendarEditor implementado (components/calendar-editor.tsx)
- ⚠️ Interface pode ser melhorada
- ❌ Cálculo de duração não considera calendário
- ❌ Exceções (feriados) não aplicadas automaticamente

---

## 🎯 Gap Analysis: O Que Falta no VisionGantt

### **CRÍTICO (Alta Prioridade)** 🔴

| # | Funcionalidade | Bryntum | VisionGantt | Gap |
|---|---------------|---------|-------------|-----|
| 1 | Colunas Redimensionáveis | ✅ | ❌ | **CRÍTICO** |
| 2 | WBS Auto-Numeração | ✅ | ❌ | **CRÍTICO** |
| 3 | Roll-up Automático | ✅ | ❌ | **CRÍTICO** |
| 4 | Dependências Visuais | ✅ | ❌ | **CRÍTICO** |
| 5 | Baseline Comparison | ✅ | ❌ | **CRÍTICO** |
| 6 | Drag & Drop Recursos | ✅ | ❌ | **CRÍTICO** |
| 7 | Edição Inline | ✅ | ❌ | **CRÍTICO** |
| 8 | Undo/Redo | ✅ | ❌ | **CRÍTICO** |

### **IMPORTANTE (Média Prioridade)** 🟡

| # | Funcionalidade | Bryntum | VisionGantt | Gap |
|---|---------------|---------|-------------|-----|
| 9 | Zoom Slider | ✅ | ❌ | **IMPORTANTE** |
| 10 | Today Marker (destaque) | ✅ | ⚠️ | **IMPORTANTE** |
| 11 | Avatares de Recursos | ✅ | ❌ | **IMPORTANTE** |
| 12 | Histograma de Carga | ✅ | ❌ | **IMPORTANTE** |
| 13 | Progress Bar Inline | ✅ | ❌ | **IMPORTANTE** |
| 14 | Drag Handles nas Barras | ✅ | ❌ | **IMPORTANTE** |
| 15 | Milestone Icons | ✅ | ⚠️ | **IMPORTANTE** |
| 16 | Calendário: Cálculo Automático | ✅ | ❌ | **IMPORTANTE** |

### **DESEJÁVEL (Baixa Prioridade)** 🟢

| # | Funcionalidade | Bryntum | VisionGantt | Gap |
|---|---------------|---------|-------------|-----|
| 17 | Tooltips Ricos | ✅ | ⚠️ | **DESEJÁVEL** |
| 18 | Labels Configuráveis nas Barras | ✅ | ⚠️ | **DESEJÁVEL** |
| 19 | Export MS Project | ✅ | ❌ | **DESEJÁVEL** |
| 20 | Settings Modal Avançado | ✅ | ❌ | **DESEJÁVEL** |

---

## 💡 Sugestões de Melhorias Priorizadas

### **FASE 1: Fundamentos Críticos** (1-2 semanas)

#### 1.1 **Colunas Redimensionáveis** 🔥

**Problema:** Colunas do grid são fixas, prejudicando usabilidade.

**Solução:**
```typescript
// Usar biblioteca react-resizable-panels ou implementar custom

import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";

<PanelGroup direction="horizontal">
  <Panel defaultSize={20} minSize={15}>
    <Column name="NAME" />
  </Panel>
  <PanelResizeHandle className="resize-handle" />
  <Panel defaultSize={10} minSize={5}>
    <Column name="% DONE" />
  </Panel>
  <PanelResizeHandle className="resize-handle" />
  <Panel defaultSize={15} minSize={10}>
    <Column name="RESOURCES" />
  </Panel>
</PanelGroup>
```

**Benefícios:**
- ✅ Usuário ajusta colunas conforme necessidade
- ✅ Melhora legibilidade em telas menores
- ✅ Persiste preferências do usuário

---

#### 1.2 **WBS Auto-Numeração e Roll-up** 🔥

**Problema:** WBS codes existem no banco mas não são exibidos/calculados.

**Solução:**

**Backend (SQL):**
```sql
-- Function para calcular WBS code automaticamente
CREATE OR REPLACE FUNCTION update_wbs_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.atividade_pai_id IS NULL THEN
    -- Root level
    NEW.codigo_wbs := (SELECT COALESCE(MAX(CAST(codigo_wbs AS INTEGER)), 0) + 1
              FROM atividades
              WHERE atividade_pai_id IS NULL
              AND projeto_id = NEW.projeto_id)::TEXT;
  ELSE
    -- Child level
    SELECT codigo_wbs INTO parent_wbs
    FROM atividades
    WHERE id = NEW.atividade_pai_id;
    
    NEW.codigo_wbs := parent_wbs || '.' ||
             (SELECT COALESCE(MAX(CAST(SPLIT_PART(codigo_wbs, '.', -1) AS INTEGER)), 0) + 1
              FROM atividades
              WHERE atividade_pai_id = NEW.atividade_pai_id)::TEXT;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_wbs_code
  BEFORE INSERT OR UPDATE ON atividades
  FOR EACH ROW
  EXECUTE FUNCTION update_wbs_code();
```

**Frontend:**
```typescript
// Componente WBSColumn
interface WBSColumnProps {
  task: Task;
}

export const WBSColumn: React.FC<WBSColumnProps> = ({ task }) => {
  return (
    <div className="flex items-center gap-2">
      <span className="font-mono text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
        {task.wbsCode}
      </span>
      <span className={cn(
        "text-sm",
        task.type === 'phase' && "font-bold",
        task.type === 'milestone' && "italic"
      )}>
        {task.name}
      </span>
    </div>
  );
};

// Roll-up automático
function calculateRollup(task: Task, children: Task[]) {
  if (children.length === 0) return task;
  
  return {
    ...task,
    startDate: min(children.map(c => c.startDate)),
    endDate: max(children.map(c => c.endDate)),
    duration: children.reduce((sum, c) => sum + c.duration, 0),
    cost: children.reduce((sum, c) => sum + c.cost, 0),
    progress: children.reduce((sum, c) => sum + (c.progress * c.duration), 0) /
        children.reduce((sum, c) => sum + c.duration, 0),
  };
}
```

**Benefícios:**
- ✅ WBS codes visíveis e corretos
- ✅ Reordenação atualiza codes automaticamente
- ✅ Roll-up facilita gestão de fases
- ✅ Conformidade com PMBOK

---

#### 1.3 **Dependências Visuais** 🔥

**Problema:** Dependências existem no banco mas não são visualizadas.

**Solução:**

```typescript
// Componente DependencyLines
import { useMemo } from 'react';

interface Dependency {
  fromTaskId: string;
  toTaskId: string;
  type: 'FS' | 'SS' | 'FF' | 'SF';
  lag?: number;
}

export const DependencyLines: React.FC<{
  tasks: Task[];
  dependencies: Dependency[];
  viewBox: { x: number; y: number; width: number; height: number };
}> = ({ tasks, dependencies, viewBox }) => {
  
  const lines = useMemo(() => {
    return dependencies.map(dep => {
    const fromTask = tasks.find(t => t.id === dep.fromTaskId);
    const toTask = tasks.find(t => t.id === dep.toTaskId);
    
    if (!fromTask || !toTask) return null;
    
    // Calcular coordenadas
    const fromPoint = getDependencyPoint(fromTask, dep.type, 'from');
    const toPoint = getDependencyPoint(toTask, dep.type, 'to');
    
    // Criar path SVG
    return createDependencyPath(fromPoint, toPoint, dep);
    }).filter(Boolean);
  }, [tasks, dependencies]);
  
  return (
    <svg className="absolute inset-0 pointer-events-none" style={{ zIndex: 1 }}>
    <defs>
    <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="5" refY="3" orient="auto">
    <polygon points="0 0, 10 3, 0 6" fill="#3b82f6" />
    </marker>
    </defs>
    {lines.map((path, idx) => (
    <path
    key={idx}
    d={path.d}
    stroke={path.color}
    strokeWidth={2}
    fill="none"
    markerEnd="url(#arrowhead)"
    className="hover:stroke-4"
    />
    ))}
    </svg>
  );
};

function getDependencyPoint(task: Task, type: string, direction: 'from' | 'to') {
  const rect = task.ref.getBoundingClientRect();
  
  switch (type) {
    case 'FS': // Finish-to-Start
    return direction === 'from'
    ? { x: rect.right, y: rect.top + rect.height / 2 }
    : { x: rect.left, y: rect.top + rect.height / 2 };
    
    case 'SS': // Start-to-Start
    return { x: rect.left, y: rect.top + rect.height / 2 };
    
    case 'FF': // Finish-to-Finish
    return { x: rect.right, y: rect.top + rect.height / 2 };
    
    case 'SF': // Start-to-Finish (raro)
    return direction === 'from'
    ? { x: rect.left, y: rect.top + rect.height / 2 }
    : { x: rect.right, y: rect.top + rect.height / 2 };
    
    default:
    return { x: rect.left, y: rect.top + rect.height / 2 };
  }
}

function createDependencyPath(from: Point, to: Point, dep: Dependency) {
  // Criar linha com cotovelos (elbow connectors)
  const midX = (from.x + to.x) / 2;
  
  const path = `
    M ${from.x} ${from.y}
    L ${midX} ${from.y}
    L ${midX} ${to.y}
    L ${to.x} ${to.y}
  `;
  
  // Cores por tipo
  const colors = {
    'FS': '#3b82f6', // Azul
    'SS': '#10b981', // Verde
    'FF': '#f59e0b', // Amarelo
    'SF': '#ef4444', // Vermelho
  };
  
  return {
    d: path,
    color: colors[dep.type],
  };
}
```

**Benefícios:**
- ✅ Dependências claramente visualizadas
- ✅ Cores diferenciam tipos (FS, SS, FF, SF)
- ✅ Hover mostra informações (lag, tipo)
- ✅ Facilita identificação de relações complexas

---

#### 1.4 **Baseline Comparison** 🔥

**Problema:** Sem visualização de baseline (plano original vs atual).

**Solução:**

**Backend:**
```sql
-- Tabela para baseline
CREATE TABLE baseline_atividades (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  atividade_id UUID NOT NULL REFERENCES atividades(id) ON DELETE CASCADE,
  baseline_id UUID NOT NULL REFERENCES baselines(id) ON DELETE CASCADE,
  data_inicio_baseline TIMESTAMP NOT NULL,
  data_fim_baseline TIMESTAMP NOT NULL,
  duracao_baseline INTEGER NOT NULL,
  custo_baseline DECIMAL(15,2),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(atividade_id, baseline_id)
);

CREATE TABLE baselines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  projeto_id UUID NOT NULL REFERENCES projetos(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  data_captura TIMESTAMP DEFAULT NOW(),
  is_active BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);
```

**Frontend:**
```typescript
// Barra de tarefa com baseline ghost
export const TaskBarWithBaseline: React.FC<{
  task: Task;
  baseline?: BaselineTask;
}> = ({ task, baseline }) => {
  
  return (
    <div className="relative">
    {/* Baseline (barra fantasma abaixo) */}
    {baseline && (
    <div
    className="absolute top-1/2 -translate-y-1/2 h-3 bg-gray-400/30 border border-gray-400/50 rounded"
    style={{
    left: calculatePosition(baseline.start),
    width: calculateWidth(baseline.start, baseline.end),
    }}
    />
    )}
    
    {/* Barra atual (por cima) */}
    <div
    className={cn(
    "relative h-6 rounded shadow-sm cursor-pointer",
    getStatusColor(task.status),
    task.isCriticalPath && "ring-2 ring-red-500"
    )}
    style={{
    left: calculatePosition(task.start),
    width: calculateWidth(task.start, task.end),
    }}
    >
    {/* Progress fill */}
    <div
    className="absolute inset-0 bg-black/20 rounded"
    style={{ width: `${task.progress}%` }}
    />
    
    {/* Label */}
    <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white">
    {task.name}
    </span>
    </div>
    
    {/* Indicador de desvio */}
    {baseline && hasDeviation(task, baseline) && (
    <div className="absolute -top-1 -right-1">
    <Badge variant="destructive" className="h-4 px-1 text-[10px]">
    {calculateDeviation(task, baseline)}d
    </Badge>
    </div>
    )}
    </div>
  );
};
```

**Benefícios:**
- ✅ Comparação visual imediata (plano vs realidade)
- ✅ Identificação rápida de atrasos
- ✅ Suporte a múltiplos baselines
- ✅ Análise de desvios facilitada

---

### **FASE 2: UX e Produtividade** (1-2 semanas)

#### 2.1 **Edição Inline**

**Solução:**
```typescript
// Célula editável
export const EditableCell: React.FC<{
  value: string;
  onSave: (newValue: string) => void;
  type?: 'text' | 'number' | 'date';
}> = ({ value, onSave, type = 'text' }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(value);
  
  const handleDoubleClick = () => setIsEditing(true);
  
  const handleSave = () => {
    onSave(tempValue);
    setIsEditing(false);
  };
  
  if (isEditing) {
    return (
    <input
    type={type}
    value={tempValue}
    onChange={(e) => setTempValue(e.target.value)}
    onBlur={handleSave}
    onKeyDown={(e) => {
    if (e.key === 'Enter') handleSave();
    if (e.key === 'Escape') setIsEditing(false);
    }}
    autoFocus
    className="w-full px-2 py-1 border rounded focus:ring-2 focus:ring-blue-500"
    />
    );
  }
  
  return (
    <div
    onDoubleClick={handleDoubleClick}
    className="px-2 py-1 cursor-pointer hover:bg-gray-50 rounded"
    >
    {value}
    </div>
  );
};
```

**Benefícios:**
- ✅ Edição rápida sem abrir modals
- ✅ UX mais fluida
- ✅ Padrão de ferramentas profissionais (Excel, MS Project)

---

#### 2.2 **Undo/Redo**

**Solução:**
```typescript
// Hook de undo/redo
export const useUndoRedo = <T,>(initialState: T) => {
  const [index, setIndex] = useState(0);
  const [history, setHistory] = useState<T[]>([initialState]);
  
  const setState = useCallback((newState: T | ((prev: T) => T)) => {
    setHistory(prev => {
    const current = typeof newState === 'function'
    ? (newState as (prev: T) => T)(prev[index])
    : newState;
    
    // Remove future states if any
    const newHistory = prev.slice(0, index + 1);
    newHistory.push(current);
    
    // Limit history to 50 items
    if (newHistory.length > 50) newHistory.shift();
    
    setIndex(newHistory.length - 1);
    return newHistory;
    });
  }, [index]);
  
  const undo = useCallback(() => {
    if (index > 0) setIndex(index - 1);
  }, [index]);
  
  const redo = useCallback(() => {
    if (index < history.length - 1) setIndex(index + 1);
  }, [index, history.length]);
  
  return {
    state: history[index],
    setState,
    undo,
    redo,
    canUndo: index > 0,
    canRedo: index < history.length - 1,
  };
};

// Uso no componente
const { state: tasks, setState: setTasks, undo, redo, canUndo, canRedo } = useUndoRedo(initialTasks);

// Keyboard shortcuts
useEffect(() => {
  const handleKeyDown = (e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
    e.preventDefault();
    if (e.shiftKey) redo();
    else undo();
    }
  };
  
  window.addEventListener('keydown', handleKeyDown);
  return () => window.removeEventListener('keydown', handleKeyDown);
}, [undo, redo]);
```

**Benefícios:**
- ✅ Desfazer erros facilmente
- ✅ Experimentar mudanças sem medo
- ✅ Shortcuts (Ctrl+Z / Ctrl+Shift+Z)

---

#### 2.3 **Zoom Slider Interativo**

**Solução:**
```typescript
// Componente ZoomSlider
export const ZoomSlider: React.FC = () => {
  const { escala, setEscala } = useCronogramaStore();
  
  const scales = ['hour', 'day', 'week', 'month', 'quarter', 'year'];
  const currentIndex = scales.indexOf(escala);
  
  return (
    <div className="flex items-center gap-3">
    <Button size="icon" variant="ghost" onClick={() => zoomOut()}>
    <MinusIcon className="h-4 w-4" />
    </Button>
    
    <Slider
    value={[currentIndex]}
    onValueChange={([value]) => setEscala(scales[value])}
    max={scales.length - 1}
    step={1}
    className="w-32"
    />
    
    <Button size="icon" variant="ghost" onClick={() => zoomIn()}>
    <PlusIcon className="h-4 w-4" />
    </Button>
    
    <span className="text-sm font-medium capitalize">
    {escala}
    </span>
    </div>
  );
};
```

**Benefícios:**
- ✅ Zoom mais intuitivo
- ✅ Visual feedback do nível de zoom
- ✅ Consistente com Bryntum

---

### **FASE 3: Recursos e Calendários** (1 semana)

#### 3.1 **Avatares de Recursos**

**Solução:**
```typescript
// Componente ResourceAvatars
export const ResourceAvatars: React.FC<{
  resources: Resource[];
  max?: number;
}> = ({ resources, max = 3 }) => {
  
  const visible = resources.slice(0, max);
  const overflow = resources.length - max;
  
  return (
    <div className="flex -space-x-2">
    {visible.map(resource => (
    <Avatar key={resource.id} className="border-2 border-white">
    {resource.avatarUrl ? (
    <AvatarImage src={resource.avatarUrl} alt={resource.name} />
    ) : (
    <AvatarFallback className={getResourceColor(resource.id)}>
    {getInitials(resource.name)}
    </AvatarFallback>
    )}
    </Avatar>
    ))}
    
    {overflow > 0 && (
    <Avatar className="border-2 border-white bg-gray-200">
    <AvatarFallback className="text-xs font-medium text-gray-600">
    +{overflow}
    </AvatarFallback>
    </Avatar>
    )}
    </div>
  );
};

// Grid column com avatares
<Column name="RESOURCES" width={120}>
  {(task) => <ResourceAvatars resources={task.assignedResources} />}
</Column>
```

**Benefícios:**
- ✅ Identificação visual rápida
- ✅ Ocupação mínima de espaço
- ✅ Visual profissional

---

#### 3.2 **Histograma de Carga de Recursos**

**Solução:**
```typescript
// Componente ResourceHistogram
export const ResourceHistogram: React.FC<{
  resourceId: string;
  dateRange: [Date, Date];
}> = ({ resourceId, dateRange }) => {
  
  const allocation = useResourceAllocation(resourceId, dateRange);
  
  return (
    <div className="space-y-2">
    <div className="flex items-center justify-between">
    <span className="text-sm font-medium">Weekly Load</span>
    <Badge variant={allocation.isOverloaded ? 'destructive' : 'success'}>
    {allocation.averageLoad}%
    </Badge>
    </div>
    
    <ResponsiveContainer width="100%" height={150}>
    <BarChart data={allocation.weeklyData}>
    <XAxis dataKey="week" />
    <YAxis domain={[0, 100]} />
    <Bar dataKey="load" fill="#3b82f6" radius={[4, 4, 0, 0]}>
    {allocation.weeklyData.map((entry, index) => (
    <Cell key={index} fill={entry.load > 100 ? '#ef4444' : '#3b82f6'} />
    ))}
    </Bar>
    <ReferenceLine y={100} stroke="#ef4444" strokeDasharray="3 3" />
    </BarChart>
    </ResponsiveContainer>
    
    {allocation.conflicts.length > 0 && (
    <Alert variant="destructive">
    <AlertCircle className="h-4 w-4" />
    <AlertTitle>Overallocation Detected</AlertTitle>
    <AlertDescription>
    {allocation.conflicts.length} conflicts in this period
    </AlertDescription>
    </Alert>
    )}
    </div>
  );
};
```

**Benefícios:**
- ✅ Visualização clara de sobrecarga
- ✅ Identificação de semanas críticas
- ✅ Facilita balanceamento de recursos

---

#### 3.3 **Cálculo Automático com Calendários**

**Solução:**
```typescript
// Função para calcular working days
export function calculateWorkingDays(
  start: Date,
  end: Date,
  calendar: WorkingCalendar
): number {
  let workingDays = 0;
  let current = new Date(start);
  
  while (current <= end) {
    const dayOfWeek = current.getDay(); // 0 = Sunday, 6 = Saturday
    
    // Check if day is working
    const dayConfig = calendar.workingDays[dayOfWeek];
    
    // Check exceptions (holidays)
    const isException = calendar.exceptions.some(exc =>
    isSameDay(exc.date, current)
    );
    
    if (dayConfig.isWorking && !isException) {
    // Calculate hours for this day
    const hours = dayConfig.periods.reduce((sum, period) => {
    return sum + calculateHoursBetween(period.start, period.end);
    }, 0);
    
    workingDays += hours / 8; // Normalize to 8h day
    } else if (isException) {
    const exception = calendar.exceptions.find(exc => isSameDay(exc.date, current));
    if (exception && exception.isWorking) {
    const hours = exception.periods.reduce((sum, period) => {
    return sum + calculateHoursBetween(period.start, period.end);
    }, 0);
    workingDays += hours / 8;
    }
    }
    
    current = addDays(current, 1);
  }
  
  return workingDays;
}

// Calcular data de fim baseada em duração
export function calculateEndDate(
  start: Date,
  durationDays: number,
  calendar: WorkingCalendar
): Date {
  let workingDaysAdded = 0;
  let current = new Date(start);
  
  while (workingDaysAdded < durationDays) {
    current = addDays(current, 1);
    
    const dayOfWeek = current.getDay();
    const dayConfig = calendar.workingDays[dayOfWeek];
    const isException = calendar.exceptions.some(exc => isSameDay(exc.date, current));
    
    if (dayConfig.isWorking && !isException) {
    const hours = dayConfig.periods.reduce((sum, period) => {
    return sum + calculateHoursBetween(period.start, period.end);
    }, 0);
    workingDaysAdded += hours / 8;
    }
  }
  
  return current;
}

// Uso no componente
const handleDurationChange = (taskId: string, newDuration: number) => {
  const task = tasks.find(t => t.id === taskId);
  const calendar = getCalendarForTask(task);
  
  const newEndDate = calculateEndDate(task.startDate, newDuration, calendar);
  
  updateTask(taskId, {
    duration: newDuration,
    endDate: newEndDate,
  });
};
```

**Benefícios:**
- ✅ Datas realistas considerando dias úteis
- ✅ Respeita feriados automaticamente
- ✅ Suporta múltiplos períodos de trabalho
- ✅ Conformidade com MS Project

---

## 📊 Resumo de Melhorias Sugeridas

### **Tabela Priorizada:**

| Prioridade | Funcionalidade | Complexidade | Impacto | Prazo |
|-----------|---------------|-------------|---------|-------|
| 🔴 **1** | Colunas Redimensionáveis | Média | Alto | 2-3 dias |
| 🔴 **2** | WBS Auto-Numeração | Média | Crítico | 3-4 dias |
| 🔴 **3** | Roll-up Automático | Alta | Crítico | 4-5 dias |
| 🔴 **4** | Dependências Visuais | Alta | Crítico | 5-7 dias |
| 🔴 **5** | Baseline Comparison | Alta | Crítico | 4-5 dias |
| 🟡 **6** | Edição Inline | Média | Alto | 3-4 dias |
| 🟡 **7** | Undo/Redo | Média | Médio | 2-3 dias |
| 🟡 **8** | Zoom Slider | Baixa | Médio | 1-2 dias |
| 🟡 **9** | Avatares de Recursos | Baixa | Médio | 1-2 dias |
| 🟡 **10** | Histograma de Carga | Média | Médio | 3-4 dias |
| 🟡 **11** | Cálculo com Calendários | Alta | Alto | 4-5 dias |
| 🟢 **12** | Tooltips Ricos | Baixa | Baixo | 1-2 dias |
| 🟢 **13** | Export MS Project | Alta | Médio | 5-7 dias |

---

## 🚀 Roadmap de Implementação

### **Sprint 1 (2 semanas): Fundamentos Críticos**
- ✅ Colunas Redimensionáveis
- ✅ WBS Auto-Numeração
- ✅ Roll-up Automático
- ✅ Dependências Visuais (fase inicial)

### **Sprint 2 (2 semanas): UX e Baseline**
- ✅ Baseline Comparison
- ✅ Edição Inline
- ✅ Undo/Redo
- ✅ Zoom Slider

### **Sprint 3 (1 semana): Recursos**
- ✅ Avatares de Recursos
- ✅ Histograma de Carga
- ✅ Drag & Drop de Recursos

### **Sprint 4 (1 semana): Calendários**
- ✅ Cálculo Automático com Calendários
- ✅ Refinamento de Exceções
- ✅ Polish e Testes

---

## 📝 Conclusão

O VisionGantt já possui uma **base sólida** com:
- ✅ Hierarquia de tarefas
- ✅ Timeline multi-nível
- ✅ Stores avançadas (recursos, cenários, calendários)
- ✅ Componentes UI modernos

### **Gaps Principais a Resolver:**

1. **Interatividade**: Falta drag & drop, edição inline, redimensionamento
2. **Visualização**: Dependências, baseline, avatares
3. **Automação**: WBS auto, roll-up, cálculos com calendários
4. **Produtividade**: Undo/redo, zoom slider, tooltips ricos

### **Próximo Passo:**

**Começar pelo Sprint 1** focando nos **fundamentos críticos** que darão base para tudo:
1. Colunas redimensionáveis
2. WBS auto-numeração
3. Roll-up automático
4. Dependências visuais

Isso vai criar a fundação para que as próximas sprints sejam mais fáceis de implementar.

---

**Você gostaria que eu comece a implementação imediata de alguma dessas melhorias?** 🚀

Posso começar por:
- [ ] Colunas Redimensionáveis
- [ ] WBS Auto-Numeração e Roll-up
- [ ] Dependências Visuais
- [ ] Baseline Comparison
- [ ] Ou outro item da sua escolha

Me avise e vamos começar! 💪

