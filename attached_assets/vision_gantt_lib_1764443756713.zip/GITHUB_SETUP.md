# 🚀 Guia de Configuração do GitHub

## Passos para Publicar no GitHub

### 1️⃣ Criar Repositório no GitHub

1. Acesse [github.com](https://github.com) e faça login
2. Clique no botão **"+"** no canto superior direito
3. Selecione **"New repository"**
4. Preencha os dados:
   - **Repository name**: `vision-gantt-lib` (ou o nome que preferir)
   - **Description**: "Biblioteca React completa para gráficos de Gantt"
   - **Visibility**: Public ou Private
   - **NÃO** marque "Initialize with README" (já temos um)
5. Clique em **"Create repository"**

### 2️⃣ Conectar ao Repositório Remoto

Apenas um dos comandos abaixo precisa ser executado:

#### Opção A: HTTPS (Recomendado)

```bash
cd /home/ubuntu/vision_gantt_lib
git remote add origin https://github.com/SEU-USUARIO/vision-gantt-lib.git
```

#### Opção B: SSH (Se você tem chave SSH configurada)

```bash
cd /home/ubuntu/vision_gantt_lib
git remote add origin git@github.com:SEU-USUARIO/vision-gantt-lib.git
```

⚠️ **Importante**: Substitua `SEU-USUARIO` pelo seu usuário do GitHub!

### 3️⃣ Verificar Conexão

```bash
git remote -v
```

Você deve ver algo como:
```
origin  https://github.com/SEU-USUARIO/vision-gantt-lib.git (fetch)
origin  https://github.com/SEU-USUARIO/vision-gantt-lib.git (push)
```

### 4️⃣ Fazer Push dos Commits

```bash
# Enviar todos os commits para o GitHub
git push -u origin master
```

Se estiver usando HTTPS, o GitHub pode solicitar suas credenciais:
- **Username**: seu-usuario-github
- **Password**: use um **Personal Access Token** (não a senha da conta)

---

## 🔑 Como Criar Personal Access Token

O GitHub não aceita mais senhas normais. Você precisa criar um token:

1. Acesse: [github.com/settings/tokens](https://github.com/settings/tokens)
2. Clique em **"Generate new token"** → **"Generate new token (classic)"**
3. Dê um nome: `vision-gantt-deploy`
4. Selecione os escopos:
   - ☑️ `repo` (acesso completo a repositórios)
5. Clique em **"Generate token"**
6. **COPIE O TOKEN** (você só verá uma vez!)
7. Use esse token como senha no `git push`

---

## 📝 Comandos Rápidos

### Verificar Status
```bash
git status
```

### Adicionar Novos Arquivos
```bash
git add .
```

### Fazer Commit
```bash
git commit -m "feat: Nova funcionalidade"
```

### Enviar para GitHub
```bash
git push
```

### Ver Histórico
```bash
git log --oneline -10
```

### Ver Commits Remotos
```bash
git log origin/master --oneline -10
```

---

## 🌿 Estrutura de Branches (Opcional)

### Criar Branch de Desenvolvimento
```bash
git checkout -b develop
git push -u origin develop
```

### Criar Branch de Feature
```bash
git checkout -b feature/nova-funcionalidade
# ... faça suas mudanças ...
git add .
git commit -m "feat: Implementa nova funcionalidade"
git push -u origin feature/nova-funcionalidade
```

### Voltar para Master
```bash
git checkout master
```

---

## 🛠️ Troubleshooting

### Erro: "remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/SEU-USUARIO/vision-gantt-lib.git
```

### Erro: "Authentication failed"
- Certifique-se de usar um Personal Access Token, não sua senha
- Gere um novo token em: [github.com/settings/tokens](https://github.com/settings/tokens)

### Erro: "Permission denied (publickey)"
- Se estiver usando SSH, configure sua chave SSH
- Ou use HTTPS em vez de SSH

### Forçar Push (use com cuidado!)
```bash
git push -f origin master
```
⚠️ **Atenção**: Só use `-f` se tiver certeza do que está fazendo!

---

## 👥 Colaboração

### Adicionar Colaboradores
1. No GitHub, vá para o repositório
2. Clique em **"Settings"** → **"Collaborators"**
3. Clique em **"Add people"**
4. Digite o username e envie o convite

### Clonar Repositório (para outros desenvolvedores)
```bash
git clone https://github.com/SEU-USUARIO/vision-gantt-lib.git
cd vision-gantt-lib/nextjs_space
yarn install
yarn dev
```

---

## 🏷️ Tags e Releases

### Criar Tag de Versão
```bash
git tag -a v1.0.0 -m "Release v1.0.0 - Initial release"
git push origin v1.0.0
```

### Criar Release no GitHub
1. Vá para a página do repositório
2. Clique em **"Releases"** → **"Create a new release"**
3. Escolha a tag `v1.0.0`
4. Adicione título e descrição
5. Anexe arquivos se necessário (opcional)
6. Clique em **"Publish release"**

---

## 📊 Status Atual

### Commits Locais
```bash
4c772a3 docs: Add comprehensive README.md
0e4558c Guias de uso criados
493ef8c Corrigidos erros de hidratação
7a5664a Complete resource management system implemented
4b344ad WBS column overflow fix + task name groups
```

Todos esses commits estarão disponíveis no GitHub após o push!

---

## ✅ Checklist

- [ ] Criar repositório no GitHub
- [ ] Copiar URL do repositório
- [ ] Executar `git remote add origin URL`
- [ ] Gerar Personal Access Token (se usar HTTPS)
- [ ] Executar `git push -u origin master`
- [ ] Verificar no GitHub se os arquivos estão lá
- [ ] Adicionar descrição e topics no repositório
- [ ] (Opcional) Criar tag de release

---

## 🌐 Tornar Público

Se o repositório for privado e você quiser torná-lo público:

1. Vá para **Settings** do repositório
2. Role até **"Danger Zone"**
3. Clique em **"Change visibility"**
4. Selecione **"Make public"**
5. Confirme digitando o nome do repositório

---

## 🚀 Próximos Passos

Após o push:
1. ✅ Adicione topics no GitHub: `react`, `gantt-chart`, `typescript`, `nextjs`
2. ✅ Edite o README.md no GitHub para adicionar seu username
3. ✅ Crie uma release v1.0.0
4. ✅ Compartilhe com a comunidade!

---

**Pronto! Sua biblioteca estará no GitHub! 🎉**
