# VisionPlan Git Configuration

# Configure seu nome e email antes do commit:
# git config user.name "Seu Nome"
# git config user.email "seu@email.com"

# Para criar o repositório no GitHub:
# 1. Acesse https://github.com/new
# 2. Crie um repositório chamado "visionplan"
# 3. Execute os comandos abaixo:

# git remote add origin https://github.com/SEU_USUARIO/visionplan.git
# git branch -M main
# git push -u origin main

# Comandos úteis:
# git status          - Ver status dos arquivos
# git add .           - Adicionar todos os arquivos
# git commit -m "msg" - Fazer commit
# git push            - Enviar para GitHub
# git pull            - Baixar do GitHub
