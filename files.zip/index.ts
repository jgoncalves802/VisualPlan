import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Usuario, Projeto, CustomTheme, ThemeColors } from '../types';

// ============================================================================
// TEMA PADRÃO (Fallback quando empresa não tem tema customizado)
// ============================================================================

export const DEFAULT_THEME: ThemeColors = {
  primary: {
    50: '#f0f9ff',
    100: '#e0f2fe',
    200: '#bae6fd',
    300: '#7dd3fc',
    400: '#38bdf8',
    500: '#0ea5e9',
    600: '#0284c7',
    700: '#0369a1',
    800: '#075985',
    900: '#0c4a6e',
  },
  secondary: {
    50: '#f8fafc',
    100: '#f1f5f9',
    200: '#e2e8f0',
    300: '#cbd5e1',
    400: '#94a3b8',
    500: '#64748b',
    600: '#475569',
    700: '#334155',
    800: '#1e293b',
    900: '#0f172a',
  },
  accent: '#8b5cf6',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  info: '#3b82f6',
  background: {
    main: '#ffffff',
    secondary: '#f8fafc',
    tertiary: '#f1f5f9',
  },
  text: {
    primary: '#0f172a',
    secondary: '#64748b',
    disabled: '#cbd5e1',
  },
};

// ============================================================================
// AUTH STORE
// ============================================================================

interface AuthState {
  usuario: Usuario | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setUsuario: (usuario: Usuario | null) => void;
  setLoading: (isLoading: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      usuario: null,
      isAuthenticated: false,
      isLoading: true,
      setUsuario: (usuario) =>
        set({
          usuario,
          isAuthenticated: !!usuario,
          isLoading: false,
        }),
      setLoading: (isLoading) => set({ isLoading }),
      logout: () =>
        set({
          usuario: null,
          isAuthenticated: false,
          isLoading: false,
        }),
    }),
    {
      name: 'visionplan-auth',
    }
  )
);

// ============================================================================
// THEME STORE (Sistema de Temas Customizáveis)
// ============================================================================

interface ThemeState {
  currentTheme: ThemeColors;
  customTheme: CustomTheme | null;
  isDarkMode: boolean;
  setCustomTheme: (theme: CustomTheme) => void;
  resetTheme: () => void;
  toggleDarkMode: () => void;
  applyTheme: () => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      currentTheme: DEFAULT_THEME,
      customTheme: null,
      isDarkMode: false,
      
      setCustomTheme: (theme) => {
        set({
          customTheme: theme,
          currentTheme: theme.colors,
        });
        get().applyTheme();
      },
      
      resetTheme: () => {
        set({
          customTheme: null,
          currentTheme: DEFAULT_THEME,
        });
        get().applyTheme();
      },
      
      toggleDarkMode: () => {
        set((state) => ({ isDarkMode: !state.isDarkMode }));
        get().applyTheme();
      },
      
      applyTheme: () => {
        const { currentTheme, isDarkMode } = get();
        const root = document.documentElement;
        
        // Aplicar cores primárias
        Object.entries(currentTheme.primary).forEach(([key, value]) => {
          root.style.setProperty(`--color-primary-${key}`, value);
        });
        
        // Aplicar cores secundárias
        Object.entries(currentTheme.secondary).forEach(([key, value]) => {
          root.style.setProperty(`--color-secondary-${key}`, value);
        });
        
        // Aplicar outras cores
        root.style.setProperty('--color-accent', currentTheme.accent);
        root.style.setProperty('--color-success', currentTheme.success);
        root.style.setProperty('--color-warning', currentTheme.warning);
        root.style.setProperty('--color-danger', currentTheme.danger);
        root.style.setProperty('--color-info', currentTheme.info);
        
        // Aplicar backgrounds
        root.style.setProperty('--color-bg-main', currentTheme.background.main);
        root.style.setProperty('--color-bg-secondary', currentTheme.background.secondary);
        root.style.setProperty('--color-bg-tertiary', currentTheme.background.tertiary);
        
        // Aplicar cores de texto
        root.style.setProperty('--color-text-primary', currentTheme.text.primary);
        root.style.setProperty('--color-text-secondary', currentTheme.text.secondary);
        root.style.setProperty('--color-text-disabled', currentTheme.text.disabled);
        
        // Dark mode toggle
        if (isDarkMode) {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
      },
    }),
    {
      name: 'visionplan-theme',
      onRehydrateStorage: () => (state) => {
        // Aplicar tema ao carregar
        if (state) {
          state.applyTheme();
        }
      },
    }
  )
);

// ============================================================================
// PROJECT STORE
// ============================================================================

interface ProjectState {
  projetoAtual: Projeto | null;
  projetos: Projeto[];
  isLoading: boolean;
  setProjetos: (projetos: Projeto[]) => void;
  setProjetoAtual: (projeto: Projeto | null) => void;
  setLoading: (isLoading: boolean) => void;
}

export const useProjectStore = create<ProjectState>()(
  persist(
    (set) => ({
      projetoAtual: null,
      projetos: [],
      isLoading: false,
      setProjetos: (projetos) => set({ projetos }),
      setProjetoAtual: (projeto) => set({ projetoAtual: projeto }),
      setLoading: (isLoading) => set({ isLoading }),
    }),
    {
      name: 'visionplan-project',
    }
  )
);

// ============================================================================
// UI STORE (Controle de sidebar, modais, etc)
// ============================================================================

interface UIState {
  sidebarOpen: boolean;
  presentationMode: boolean;
  currentModule: string;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
  setPresentationMode: (mode: boolean) => void;
  togglePresentationMode: () => void;
  setCurrentModule: (module: string) => void;
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: true,
  presentationMode: false,
  currentModule: 'dashboard',
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setPresentationMode: (mode) => set({ presentationMode: mode }),
  togglePresentationMode: () =>
    set((state) => ({ presentationMode: !state.presentationMode })),
  setCurrentModule: (module) => set({ currentModule: module }),
}));

// ============================================================================
// NOTIFICATION STORE
// ============================================================================

interface NotificationState {
  notifications: Array<{
    id: string;
    tipo: string;
    titulo: string;
    mensagem: string;
    lida: boolean;
    createdAt: Date;
  }>;
  unreadCount: number;
  addNotification: (notification: any) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearNotifications: () => void;
}

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  unreadCount: 0,
  addNotification: (notification) =>
    set((state) => ({
      notifications: [notification, ...state.notifications],
      unreadCount: state.unreadCount + 1,
    })),
  markAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === id ? { ...n, lida: true } : n
      ),
      unreadCount: Math.max(0, state.unreadCount - 1),
    })),
  markAllAsRead: () =>
    set((state) => ({
      notifications: state.notifications.map((n) => ({ ...n, lida: true })),
      unreadCount: 0,
    })),
  clearNotifications: () =>
    set({ notifications: [], unreadCount: 0 }),
}));
